"""Read a ZIP archive safely and keep only the source files worth inspecting.

Design notes
------------
* The archive is never extracted to disk: entries are read straight from memory.
  That removes zip-slip (path traversal) and temp-file cleanup from the threat model.
* Build artifacts, dependency folders, binaries, lockfiles and minified bundles are
  filtered out *before* anything is read, so a 30 MB repo with `node_modules`
  committed costs us almost nothing.
* Hard caps (per-file size, file count, total uncompressed bytes) protect the
  free-tier instance (512 MB RAM) against zip bombs and monorepos.
"""

from __future__ import annotations

import io
import posixpath
import stat
import zipfile
import zlib
from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field

from app.errors import IngestError

IGNORED_DIRS = frozenset(
    {
        # JS / TS ecosystem
        "node_modules", "bower_components", "jspm_packages", ".next", ".nuxt", ".output", ".svelte-kit",
        ".vercel", ".netlify", ".turbo", ".cache", ".parcel-cache", ".expo", ".docusaurus", "storybook-static",
        "dist", "build", "out", "coverage",
        # Python
        "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".venv", "venv", ".tox", "site-packages",
        # Other toolchains / IDEs / VCS
        ".git", ".hg", ".svn", ".idea", ".vscode", "vendor", "target", "bin", "obj", ".gradle", "Pods",
        "DerivedData", ".terraform", "__MACOSX",
    }
)

BINARY_EXTENSIONS = frozenset(
    {
        # images / design
        ".png", ".jpg", ".jpeg", ".gif", ".webp", ".avif", ".bmp", ".ico", ".icns", ".svg", ".tif", ".tiff",
        ".psd", ".ai", ".sketch", ".fig",
        # media
        ".mp3", ".mp4", ".mov", ".avi", ".webm", ".wav", ".ogg", ".flac", ".m4a",
        # fonts
        ".woff", ".woff2", ".ttf", ".otf", ".eot",
        # archives / executables / compiled
        ".zip", ".tar", ".gz", ".tgz", ".bz2", ".xz", ".7z", ".rar", ".jar", ".war", ".exe", ".dll", ".so",
        ".dylib", ".a", ".o", ".class", ".pyc", ".pyo", ".wasm", ".bin", ".dat",
        # data / models / docs
        ".db", ".sqlite", ".sqlite3", ".parquet", ".pkl", ".npy", ".npz", ".h5", ".onnx", ".pt", ".pth", ".ckpt",
        ".pdf", ".map", ".lockb",
    }
)

LOCKFILES = frozenset(
    {
        "package-lock.json", "yarn.lock", "pnpm-lock.yaml", "bun.lockb", "bun.lock", "npm-shrinkwrap.json",
        "poetry.lock", "pipfile.lock", "uv.lock", "composer.lock", "cargo.lock", "gemfile.lock", "go.sum",
    }
)

JUNK_FILENAMES = frozenset({".ds_store", "thumbs.db"})


@dataclass(frozen=True)
class SourceFile:
    path: str
    content: str
    size: int

    @property
    def name(self) -> str:
        return posixpath.basename(self.path)

    @property
    def ext(self) -> str:
        return posixpath.splitext(self.path)[1].lower()

    @property
    def line_count(self) -> int:
        return self.content.count("\n") + 1


@dataclass
class ArchiveStats:
    total_entries: int = 0
    kept_files: int = 0
    kept_bytes: int = 0
    skipped_artifacts: int = 0
    skipped_binary: int = 0
    skipped_lockfiles: int = 0
    skipped_large: int = 0
    skipped_unsafe: int = 0
    truncated: bool = False
    ignored_dirs: Counter[str] = field(default_factory=Counter)

    @property
    def skipped_total(self) -> int:
        return (
            self.skipped_artifacts + self.skipped_binary + self.skipped_lockfiles
            + self.skipped_large + self.skipped_unsafe
        )

    def as_dict(self) -> dict[str, object]:
        return {
            "total_entries": self.total_entries,
            "kept_files": self.kept_files,
            "kept_bytes": self.kept_bytes,
            "skipped_artifacts": self.skipped_artifacts,
            "skipped_binary": self.skipped_binary,
            "skipped_lockfiles": self.skipped_lockfiles,
            "skipped_large": self.skipped_large,
            "skipped_unsafe": self.skipped_unsafe,
            "truncated": self.truncated,
            "ignored_dirs": dict(self.ignored_dirs.most_common(15)),
        }


@dataclass
class ArchiveContents:
    files: list[SourceFile]
    # Every non-ignored path, including binaries/lockfiles (used for the tree and stack detection).
    all_paths: list[str]
    stats: ArchiveStats


def _common_root(names: Iterable[str]) -> str:
    """GitHub zipballs wrap everything in `<owner>-<repo>-<sha>/`; detect and strip that."""
    names = list(names)
    if not names or not all("/" in n for n in names):
        return ""
    roots = {n.split("/", 1)[0] for n in names}
    return f"{roots.pop()}/" if len(roots) == 1 else ""


def _normalise(name: str, root: str) -> str | None:
    path = name.replace("\\", "/")
    if root and path.startswith(root):
        path = path[len(root):]
    if not path or path.startswith("/") or ":" in path.split("/", 1)[0]:
        return None
    if any(part in ("..", "") for part in path.split("/")):
        return None
    return path


def _is_symlink(info: zipfile.ZipInfo) -> bool:
    return stat.S_ISLNK(info.external_attr >> 16)


def read_archive(
    data: bytes,
    *,
    max_file_bytes: int,
    max_files: int,
    max_total_bytes: int,
) -> ArchiveContents:
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as exc:
        raise IngestError("The archive is not a valid ZIP file.", http_status=422) from exc

    stats = ArchiveStats()
    files: list[SourceFile] = []
    all_paths: list[str] = []

    with zf:
        infos = sorted((i for i in zf.infolist() if not i.is_dir()), key=lambda i: i.filename)
        stats.total_entries = len(infos)
        root = _common_root(i.filename for i in infos)

        for info in infos:
            path = _normalise(info.filename, root)
            if path is None or _is_symlink(info) or info.flag_bits & 0x1:  # traversal / symlink / encrypted
                stats.skipped_unsafe += 1
                continue

            parts = path.split("/")
            ignored = next((p for p in parts[:-1] if p in IGNORED_DIRS), None)
            if ignored:
                stats.skipped_artifacts += 1
                stats.ignored_dirs[ignored] += 1
                continue

            all_paths.append(path)
            name = parts[-1].lower()
            ext = posixpath.splitext(name)[1]

            if name in JUNK_FILENAMES or ext in BINARY_EXTENSIONS:
                stats.skipped_binary += 1
                continue
            if name in LOCKFILES:
                stats.skipped_lockfiles += 1
                continue
            if name.endswith((".min.js", ".min.css", ".bundle.js", ".chunk.js")):
                stats.skipped_artifacts += 1
                continue
            if info.file_size > max_file_bytes:
                stats.skipped_large += 1
                continue
            if stats.kept_files >= max_files or stats.kept_bytes + info.file_size > max_total_bytes:
                stats.truncated = True
                continue

            try:
                with zf.open(info) as fh:
                    raw = fh.read(max_file_bytes + 1)  # never trust the declared size
            except (zipfile.BadZipFile, zlib.error, RuntimeError, NotImplementedError, OSError):
                stats.skipped_unsafe += 1
                continue

            if len(raw) > max_file_bytes:
                stats.skipped_large += 1
                continue
            if b"\x00" in raw[:8192]:
                stats.skipped_binary += 1
                continue

            files.append(SourceFile(path=path, content=raw.decode("utf-8", errors="replace"), size=len(raw)))
            stats.kept_files += 1
            stats.kept_bytes += len(raw)

    if not files:
        raise IngestError("No inspectable source files were found in the archive.", http_status=422)

    return ArchiveContents(files=files, all_paths=all_paths, stats=stats)


def render_tree(paths: list[str], *, max_depth: int = 3, max_lines: int = 120) -> str:
    """Compact directory overview: folders (with file counts) up to `max_depth`, plus root files."""
    dir_counts: Counter[str] = Counter()
    root_files: list[str] = []
    for p in paths:
        parts = p.split("/")
        if len(parts) == 1:
            root_files.append(p)
            continue
        for depth in range(1, min(len(parts), max_depth + 1)):
            dir_counts["/".join(parts[:depth])] += 1

    lines: list[str] = []
    for d in sorted(dir_counts, key=lambda d: d.split("/")):
        depth = d.count("/")
        lines.append(f"{'  ' * depth}{d.rsplit('/', 1)[-1]}/  ({dir_counts[d]} files)")
    lines.extend(sorted(root_files))

    if len(lines) > max_lines:
        hidden = len(lines) - max_lines
        lines = lines[:max_lines] + [f"... ({hidden} more entries)"]
    return "\n".join(lines)
