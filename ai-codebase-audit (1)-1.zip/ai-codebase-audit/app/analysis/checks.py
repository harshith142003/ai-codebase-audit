"""Deterministic (non-LLM) checks that turn scan results into findings.

These are cheap, reproducible and never hallucinate, so they run on every
audit and are stored alongside the LLM's findings with `source = 'static'`.
"""

from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass

from app.analysis.archive import SourceFile
from app.analysis.db_schema import DatabaseSchema
from app.analysis.manifests import Manifest
from app.analysis.secrets import SecretHit
from app.models.enums import SEVERITY_RANK, EffortLevel, FindingCategory, FindingSource, Severity

_CLIENT_PRIVILEGED_ENV_RE = re.compile(
    r"\b(?:VITE|NEXT_PUBLIC|REACT_APP|EXPO_PUBLIC|PUBLIC|NUXT_PUBLIC)_[A-Z0-9_]*(?:SERVICE_ROLE|SECRET|PRIVATE)[A-Z0-9_]*\b"
)
_ENV_FILE_RE = re.compile(r"(^|/)\.env(\.[\w-]+)?$")
_ENV_TEMPLATE_RE = re.compile(r"\.(example|sample|template|dist)$", re.I)
_PUBLIC_ENV_PREFIXES = ("VITE_", "NEXT_PUBLIC_", "REACT_APP_", "EXPO_PUBLIC_", "PUBLIC_", "NUXT_PUBLIC_")
_TEST_FILE_RE = re.compile(r"(^|/)(tests?|__tests__)/|\.(test|spec)\.[jt]sx?$|(^|/)test_[^/]+\.py$|_test\.py$")


@dataclass
class StaticFinding:
    category: FindingCategory
    severity: Severity
    title: str
    description: str
    recommendation: str
    file_path: str | None
    effort: EffortLevel
    source: FindingSource = FindingSource.STATIC

    def as_row(self) -> dict[str, str | None]:
        return {
            "category": self.category.value,
            "severity": self.severity.value,
            "source": self.source.value,
            "title": self.title,
            "description": self.description,
            "recommendation": self.recommendation,
            "file_path": self.file_path,
            "effort": self.effort.value,
        }


def _locations(items: list[str], limit: int = 6) -> str:
    shown = ", ".join(f"`{i}`" for i in items[:limit])
    return shown + (f" and {len(items) - limit} more" if len(items) > limit else "")


def find_env_files(files: list[SourceFile]) -> list[SourceFile]:
    return [f for f in files if _ENV_FILE_RE.search(f.path) and not _ENV_TEMPLATE_RE.search(f.path)]


def find_test_files(files: list[SourceFile]) -> list[str]:
    return [f.path for f in files if _TEST_FILE_RE.search(f.path)]


def check_secrets(hits: list[SecretHit]) -> list[StaticFinding]:
    by_kind: dict[str, list[SecretHit]] = defaultdict(list)
    for h in hits:
        by_kind[h.kind].append(h)

    findings: list[StaticFinding] = []
    for kind, group in by_kind.items():
        first = group[0]
        locs = [f"{h.file}:{h.line}" for h in group]
        if kind == "supabase_anon_key" or kind == "supabase_publishable_key":
            findings.append(
                StaticFinding(
                    category=FindingCategory.SECURITY,
                    severity=Severity.INFO,
                    title="Supabase public (anon/publishable) key embedded in client code",
                    description=(
                        f"Found in {_locations(locs)}. This key is public by design, which means every table is "
                        "protected only by Row Level Security policies — any table without correct RLS is readable "
                        "and writable by anyone holding this key."
                    ),
                    recommendation="Keep the key in environment config and verify RLS + policies on every table.",
                    file_path=first.file,
                    effort=EffortLevel.LOW,
                )
            )
            continue
        findings.append(
            StaticFinding(
                category=FindingCategory.SECURITY,
                severity=first.severity,
                title=f"Hardcoded secret: {first.label}" + (f" ({len(group)} occurrences)" if len(group) > 1 else ""),
                description=(
                    f"A credential matching `{kind}` is committed to source control at {_locations(locs)} "
                    f"(value preview: {first.preview}). Anyone with repository or bundle access can use it."
                ),
                recommendation=(
                    "Rotate the credential immediately, move it to server-side environment variables / a secrets "
                    "manager, and purge it from git history (e.g. git filter-repo)."
                ),
                file_path=first.file,
                effort=EffortLevel.LOW,
            )
        )
    return findings


def check_env_files(env_files: list[SourceFile]) -> list[StaticFinding]:
    if not env_files:
        return []
    private_vars: list[str] = []
    for f in env_files:
        for line in f.content.splitlines():
            key = line.split("=", 1)[0].strip().removeprefix("export ").strip()
            if "=" in line and key and not key.startswith("#") and not key.startswith(_PUBLIC_ENV_PREFIXES):
                private_vars.append(key)
    paths = [f.path for f in env_files]
    if private_vars:
        return [
            StaticFinding(
                category=FindingCategory.SECURITY,
                severity=Severity.HIGH,
                title="Environment file with server-side variables committed to the repository",
                description=(
                    f"{_locations(paths)} is tracked in git and defines non-public variables "
                    f"({_locations(sorted(set(private_vars)), 8)})."
                ),
                recommendation="Remove the file from git, add `.env*` to .gitignore, rotate the values, ship a `.env.example`.",
                file_path=paths[0],
                effort=EffortLevel.LOW,
            )
        ]
    return [
        StaticFinding(
            category=FindingCategory.SECURITY,
            severity=Severity.LOW,
            title="Committed .env file (client-side variables only)",
            description=(
                f"{_locations(paths)} is tracked in git. It currently holds only browser-exposed variables, but the "
                "pattern makes it easy for a real secret to be committed later."
            ),
            recommendation="Untrack the file, add it to .gitignore and provide a `.env.example` instead.",
            file_path=paths[0],
            effort=EffortLevel.LOW,
        )
    ]


def check_client_privileged_env(files: list[SourceFile]) -> list[StaticFinding]:
    hits = sorted({f"{f.path} ({m})" for f in files for m in _CLIENT_PRIVILEGED_ENV_RE.findall(f.content)})
    if not hits:
        return []
    return [
        StaticFinding(
            category=FindingCategory.SECURITY,
            severity=Severity.CRITICAL,
            title="Privileged secret exposed through a client-side environment variable",
            description=(
                f"Variables with a browser-exposed prefix carry privileged values: {_locations(hits)}. Bundlers inline "
                "these into the JavaScript shipped to every visitor."
            ),
            recommendation="Move privileged operations to a server route / edge function and rotate the exposed key.",
            file_path=hits[0].split(" ")[0],
            effort=EffortLevel.MEDIUM,
        )
    ]


def check_database(db: DatabaseSchema, frameworks: list[str]) -> list[StaticFinding]:
    findings: list[StaticFinding] = []
    uses_supabase = "Supabase" in frameworks

    missing_rls = db.tables_without_rls()
    if uses_supabase and missing_rls:
        findings.append(
            StaticFinding(
                category=FindingCategory.SECURITY,
                severity=Severity.CRITICAL if len(missing_rls) == len(db.tables) else Severity.HIGH,
                title=f"Row Level Security not enabled on {len(missing_rls)} public table(s)",
                description=(
                    f"No `ENABLE ROW LEVEL SECURITY` statement was found for {_locations(missing_rls, 10)}. With "
                    "Supabase, the anon key is shipped to the browser, so these tables are exposed through the "
                    "auto-generated REST API."
                ),
                recommendation="Enable RLS on every public table and add least-privilege policies (e.g. `auth.uid() = user_id`).",
                file_path=db.tables[missing_rls[0]].source_file,
                effort=EffortLevel.MEDIUM,
            )
        )

    no_policies = db.tables_with_rls_but_no_policies()
    if uses_supabase and no_policies:
        findings.append(
            StaticFinding(
                category=FindingCategory.SECURITY,
                severity=Severity.INFO,
                title="Tables with RLS enabled but no policies in migrations",
                description=(
                    f"{_locations(no_policies, 10)} deny all client access. That is safe, but if the app reads these "
                    "tables from the browser, policies may have been created ad-hoc in the dashboard and are not "
                    "version-controlled."
                ),
                recommendation="Capture every policy in migrations so environments are reproducible.",
                file_path=db.tables[no_policies[0]].source_file,
                effort=EffortLevel.LOW,
            )
        )

    unindexed = db.unindexed_foreign_keys()
    if unindexed:
        items = [f"{t}.{c} → {r}" for t, c, r in unindexed]
        findings.append(
            StaticFinding(
                category=FindingCategory.DATABASE,
                severity=Severity.MEDIUM if len(unindexed) < 5 else Severity.HIGH,
                title=f"{len(unindexed)} foreign-key column(s) without a supporting index",
                description=(
                    f"Postgres does not index foreign keys automatically. Unindexed: {_locations(items, 10)}. Joins, "
                    "lookups by parent and ON DELETE cascades will degrade to sequential scans as data grows."
                ),
                recommendation="Add a btree index per FK column (or a composite index led by it) in a new migration.",
                file_path=db.tables[unindexed[0][0]].source_file,
                effort=EffortLevel.LOW,
            )
        )

    if uses_supabase and not db.has_sql_schema and not db.orm_models:
        detail = (
            f" Tables are visible only through generated types ({_locations(db.typed_tables, 8)})."
            if db.typed_tables
            else ""
        )
        findings.append(
            StaticFinding(
                category=FindingCategory.DATABASE,
                severity=Severity.MEDIUM,
                title="Database schema is not version-controlled",
                description=(
                    "The app uses Supabase but the repository contains no SQL migrations or ORM schema, so indexes, "
                    f"constraints and RLS policies cannot be reviewed or reproduced.{detail}"
                ),
                recommendation="Pull the live schema with `supabase db pull` and manage all changes as migrations.",
                file_path=None,
                effort=EffortLevel.LOW,
            )
        )

    if len(db.data_access) >= 3:
        ui_files = sorted({p for paths in db.data_access.values() for p in paths if "/components/" in p or "/pages/" in p})
        if len(ui_files) >= 3:
            findings.append(
                StaticFinding(
                    category=FindingCategory.ARCHITECTURE,
                    severity=Severity.MEDIUM,
                    title=f"Database queries issued directly from {len(ui_files)} UI components",
                    description=(
                        f"Supabase queries are embedded in presentation code ({_locations(ui_files)}). Business rules, "
                        "validation and query shapes are duplicated and hard to test or secure centrally."
                    ),
                    recommendation="Introduce a data-access layer (hooks/services) and move privileged logic server-side.",
                    file_path=ui_files[0],
                    effort=EffortLevel.MEDIUM,
                )
            )
    return findings


def check_xss(files: list[SourceFile], manifests: list[Manifest]) -> list[StaticFinding]:
    deps = set().union(*(m.all_names for m in manifests)) if manifests else set()
    hits = [f.path for f in files if f.ext in (".tsx", ".jsx", ".js", ".ts") and "dangerouslySetInnerHTML" in f.content]
    hits = [h for h in hits if "/components/ui/" not in h]  # shadcn's chart.tsx uses it for static CSS
    if not hits or "dompurify" in deps or "isomorphic-dompurify" in deps:
        return []
    return [
        StaticFinding(
            category=FindingCategory.SECURITY,
            severity=Severity.MEDIUM,
            title="Raw HTML rendering without a sanitiser",
            description=(
                f"`dangerouslySetInnerHTML` is used in {_locations(hits)} and no HTML sanitiser (e.g. DOMPurify) is a "
                "dependency. If any of that HTML is user-controlled this is a stored XSS vector."
            ),
            recommendation="Sanitise with DOMPurify or render Markdown through a safe renderer.",
            file_path=hits[0],
            effort=EffortLevel.LOW,
        )
    ]


def check_tests(test_files: list[str], source_file_count: int) -> list[StaticFinding]:
    if test_files or source_file_count < 10:
        return []
    return [
        StaticFinding(
            category=FindingCategory.ARCHITECTURE,
            severity=Severity.LOW,
            title="No automated tests",
            description=f"None of the {source_file_count} source files are tests, so refactoring carries regression risk.",
            recommendation="Add smoke tests around auth and data-mutation flows before remediation work begins.",
            file_path=None,
            effort=EffortLevel.MEDIUM,
        )
    ]


def sort_findings(findings: list[StaticFinding]) -> list[StaticFinding]:
    return sorted(findings, key=lambda f: (SEVERITY_RANK[f.severity.value], f.category.value))
