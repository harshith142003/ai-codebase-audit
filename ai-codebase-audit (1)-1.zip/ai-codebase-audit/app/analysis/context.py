"""Pack the most audit-relevant code into the LLM's context budget.

Free-tier models have small token budgets, so *what* we send matters more than
*how much*. Files are ranked by audit value (manifests, schema, auth, routes and
data access first; generated UI kit components last), secrets are redacted, and
large files are truncated rather than dropped.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass

from app.analysis.archive import SourceFile
from app.analysis.scanner import ScanResult
from app.analysis.secrets import redact

_MANIFESTS = {"package.json", "requirements.txt", "pyproject.toml", "schema.prisma", "go.mod"}
_HIGH_VALUE_RE = re.compile(r"(auth|middleware|supabase/client|lib/supabase|security|session|permission|guard)", re.I)
_SERVICE_DIR_RE = re.compile(r"(^|/)(server|api|lib|services?|hooks|utils|store|actions|db|models|repositories)/", re.I)
_CONFIG_RE = re.compile(r"(^|/)(next|vite|nuxt|svelte|astro)\.config\.|(^|/)tsconfig\.json$|(^|/)vercel\.json$")
_UI_KIT_RE = re.compile(r"(^|/)components/ui/")


@dataclass
class ContextBundle:
    summary_json: str
    files_text: str
    included: list[str]
    omitted: list[str]

    @property
    def char_count(self) -> int:
        return len(self.summary_json) + len(self.files_text)


def file_priority(f: SourceFile, route_files: set[str], data_access_files: set[str]) -> int:
    path, name = f.path, f.name.lower()
    if name.startswith(".env"):
        return -1  # never sent: covered by deterministic checks
    if name in _MANIFESTS or (name.startswith("requirements") and name.endswith(".txt")):
        return 100 if path.count("/") <= 1 else 35  # root/app manifests matter; nested copies rarely do
    if f.ext == ".sql" or ("supabase" in path and name.startswith("types")):
        return 95
    if path in route_files:
        return 90
    if _HIGH_VALUE_RE.search(path):
        return 88
    if path in data_access_files:
        return 80
    if _UI_KIT_RE.search(path):
        return 8  # generated shadcn/ui primitives: low audit value
    if _SERVICE_DIR_RE.search(path):
        return 70
    if f.ext in (".ts", ".tsx", ".js", ".jsx", ".py", ".vue", ".svelte", ".mjs", ".cjs"):
        if re.search(r"\.(test|spec)\.", path) or "/tests/" in f"/{path}":
            return 15
        return 55
    if _CONFIG_RE.search(path):
        return 40
    if name == "readme.md":
        return 30
    if f.ext == ".html":
        return 20
    return 5


def build_context(scan: ScanResult, budget_chars: int) -> ContextBundle:
    # The structured summary is the most information-dense input; give it up to ~35% of the budget,
    # shrinking list sizes (rather than cutting JSON mid-way) until it fits.
    summary_cap = int(budget_chars * 0.35)
    for scale in (1.0, 0.6, 0.35, 0.2, 0.1):
        summary_json = json.dumps(scan.llm_summary(scale), separators=(",", ":"), default=str)
        if len(summary_json) <= summary_cap:
            break
    else:
        summary_json = summary_json[:summary_cap] + "...(truncated)"

    route_files = {r.file for r in scan.routes}
    data_access_files = {p for paths in scan.database.data_access.values() for p in paths}
    hits_by_file: dict[str, list] = {}
    for h in scan.secret_hits:
        hits_by_file.setdefault(h.file, []).append(h)

    ranked = sorted(
        ((file_priority(f, route_files, data_access_files), f) for f in scan.files),
        key=lambda pf: (-pf[0], pf[1].path.count("/"), pf[1].size),  # shallow + small first within a tier
    )

    file_budget = budget_chars - len(summary_json)
    remaining = file_budget
    sql_budget = int(file_budget * 0.25)  # schema is already summarised; keep raw SQL from crowding out code
    seen_hashes: set[int] = set()
    chunks: list[str] = []
    included: list[str] = []
    omitted: list[str] = []
    for priority, f in ranked:
        if priority < 0:
            continue
        digest = hash(f.content)
        if digest in seen_hashes:  # duplicated files (copied folders, vendored snapshots)
            omitted.append(f.path)
            continue
        is_sql = f.ext == ".sql"
        if remaining < 600 or (is_sql and sql_budget < 600):
            omitted.append(f.path)
            continue
        seen_hashes.add(digest)
        per_file_cap = 6_000 if is_sql else 9_000 if priority >= 88 else 5_000
        if is_sql:
            per_file_cap = min(per_file_cap, sql_budget)
        content = redact(f.content, hits_by_file.get(f.path, []))
        cap = min(per_file_cap, remaining - 200)
        truncated = len(content) > cap
        body = content[:cap] + ("\n... [truncated]" if truncated else "")
        header = f"===== FILE: {f.path} ({f.size} bytes{', truncated' if truncated else ''}) ====="
        chunk = f"{header}\n{body}\n"
        chunks.append(chunk)
        included.append(f.path)
        remaining -= len(chunk)
        if is_sql:
            sql_budget -= len(chunk)

    return ContextBundle(summary_json=summary_json, files_text="\n".join(chunks), included=included, omitted=omitted)
