"""Database schema analysis.

Parses SQL migrations (Supabase / plain Postgres), Prisma and Drizzle schemas,
and Supabase-generated TypeScript types, then answers two questions with
deterministic logic rather than LLM guesswork:

1. Which foreign-key columns have no supporting index?  Postgres does NOT index
   FK columns automatically, so joins and `ON DELETE CASCADE` scans degrade as
   tables grow. This is the single most common indexing gap in AI-built apps.
2. Which public tables never enable Row Level Security?  With Supabase, the
   anon key ships to every browser, so a table without RLS is world-readable.
"""

from __future__ import annotations

import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field

from app.analysis.archive import SourceFile

_IDENT = r'(?:"[^"]+"|[A-Za-z_][\w$]*)'
_QUALIFIED = rf"{_IDENT}(?:\s*\.\s*{_IDENT})?"

_CREATE_TABLE_RE = re.compile(
    rf"\bcreate\s+(?:or\s+replace\s+)?(?:(?:global|local)\s+)?(?:temp(?:orary)?\s+|unlogged\s+)?table\s+"
    rf"(?:if\s+not\s+exists\s+)?(?P<name>{_QUALIFIED})\s*\(",
    re.I,
)
_ALTER_TABLE_RE = re.compile(
    rf"\balter\s+table\s+(?:if\s+exists\s+)?(?:only\s+)?(?P<name>{_QUALIFIED})\s+(?P<body>[^;]*)", re.I
)
_CREATE_INDEX_RE = re.compile(
    rf"\bcreate\s+(?P<unique>unique\s+)?index\s+(?:concurrently\s+)?(?:if\s+not\s+exists\s+)?"
    rf"(?:(?P<name>{_IDENT})\s+)?on\s+(?:only\s+)?(?P<table>{_QUALIFIED})\s*(?:using\s+\w+\s*)?\(",
    re.I,
)
_CREATE_POLICY_RE = re.compile(rf"\bcreate\s+policy\s+{_IDENT}\s+on\s+(?P<table>{_QUALIFIED})", re.I)
_REFERENCES_RE = re.compile(rf"\breferences\s+(?P<ref>{_QUALIFIED})", re.I)
_CONSTRAINT_PREFIX_RE = re.compile(rf"^constraint\s+{_IDENT}\s+", re.I)
_FK_CONSTRAINT_RE = re.compile(
    rf"^foreign\s+key\s*\((?P<cols>[^)]*)\)\s*references\s+(?P<ref>{_QUALIFIED})", re.I
)

_PRISMA_MODEL_RE = re.compile(r"^\s*model\s+(\w+)\s*\{", re.M)
_DRIZZLE_TABLE_RE = re.compile(r"\b(?:pgTable|mysqlTable|sqliteTable)\(\s*['\"`](\w+)['\"`]")
_SUPABASE_TYPES_TABLE_RE = re.compile(r"(\w+)\s*:\s*\{\s*Row\s*:\s*\{")
_SUPABASE_FROM_RE = re.compile(r"(?<!Buffer)(?<!Array)(?<!Object)\.from\(\s*['\"`]([\w.-]+)['\"`]\s*\)")
_SUPABASE_RPC_RE = re.compile(r"\.rpc\(\s*['\"`]([\w.-]+)['\"`]")


@dataclass
class TableInfo:
    name: str
    schema: str | None
    source_file: str
    columns: list[str] = field(default_factory=list)
    primary_key: list[str] = field(default_factory=list)
    foreign_keys: list[tuple[str, str]] = field(default_factory=list)  # (leading column, referenced table)
    unique_leading: set[str] = field(default_factory=set)

    @property
    def is_public(self) -> bool:
        return self.schema in (None, "public")


@dataclass
class IndexInfo:
    name: str | None
    table: str
    leading_column: str
    columns: list[str]
    unique: bool
    source_file: str


@dataclass
class DatabaseSchema:
    tables: dict[str, TableInfo] = field(default_factory=dict)
    indexes: list[IndexInfo] = field(default_factory=list)
    rls_enabled: set[str] = field(default_factory=set)
    policy_counts: Counter[str] = field(default_factory=Counter)
    migration_files: list[str] = field(default_factory=list)
    orm_models: list[str] = field(default_factory=list)
    typed_tables: list[str] = field(default_factory=list)  # from Supabase-generated TS types
    data_access: dict[str, list[str]] = field(default_factory=dict)  # table -> files calling .from(table)
    rpc_calls: dict[str, list[str]] = field(default_factory=dict)

    # --- derived checks --------------------------------------------------------------------
    def unindexed_foreign_keys(self) -> list[tuple[str, str, str]]:
        covered: dict[str, set[str]] = defaultdict(set)
        for idx in self.indexes:
            covered[idx.table].add(idx.leading_column)
        for t in self.tables.values():
            if t.primary_key:
                covered[t.name].add(t.primary_key[0])
            covered[t.name] |= t.unique_leading
        missing: list[tuple[str, str, str]] = []
        for t in self.tables.values():
            for col, ref in t.foreign_keys:
                if col not in covered[t.name] and (t.name, col, ref) not in missing:
                    missing.append((t.name, col, ref))
        return missing

    def tables_without_rls(self) -> list[str]:
        return sorted(name for name, t in self.tables.items() if t.is_public and name not in self.rls_enabled)

    def tables_with_rls_but_no_policies(self) -> list[str]:
        return sorted(t for t in self.rls_enabled if t in self.tables and self.policy_counts[t] == 0)

    @property
    def has_sql_schema(self) -> bool:
        return bool(self.tables)

    def compact_summary(self, scale: float = 1.0) -> dict[str, object]:
        """Dense, string-based summary for the LLM prompt. `scale` shrinks list caps to fit a budget."""
        n = lambda base: max(3, int(base * scale))  # noqa: E731
        tables = []
        for t in list(self.tables.values())[: n(60)]:
            fks = ",".join(f"{c}->{r}" for c, r in t.foreign_keys)
            rls = "on" if t.name in self.rls_enabled else "OFF"
            cols = ",".join(t.columns[: n(14)]) + (",…" if len(t.columns) > n(14) else "")
            tables.append(
                f"{t.name}({cols}) pk={','.join(t.primary_key) or '-'} fk=[{fks}] "
                f"rls={rls} policies={self.policy_counts.get(t.name, 0)}"
            )
        unindexed = [f"{t}.{c}->{r}" for t, c, r in self.unindexed_foreign_keys()]
        return {
            "migration_file_count": len(self.migration_files),
            "tables": tables,
            "tables_total": len(self.tables),
            "indexes": [f"{i.table}({','.join(i.columns)}){' unique' if i.unique else ''}" for i in self.indexes[: n(40)]],
            "indexes_total": len(self.indexes),
            "unindexed_foreign_keys": unindexed[: n(30)],
            "unindexed_foreign_keys_total": len(unindexed),
            "tables_without_rls": self.tables_without_rls()[: n(40)],
            "orm_models": self.orm_models[: n(40)],
            "supabase_typed_tables": self.typed_tables[: n(60)],
            "client_data_access": {
                t: f"{len(files)} file(s), e.g. {', '.join(files[:2])}" for t, files in list(self.data_access.items())[: n(30)]
            },
            "rpc_calls": list(self.rpc_calls)[: n(20)],
        }

    def summary(self, *, max_tables: int = 40) -> dict[str, object]:
        tables = []
        for t in list(self.tables.values())[:max_tables]:
            tables.append(
                {
                    "name": t.name,
                    "columns": t.columns[:25],
                    "primary_key": t.primary_key,
                    "foreign_keys": [f"{c} -> {r}" for c, r in t.foreign_keys],
                    "rls_enabled": t.name in self.rls_enabled,
                    "policies": self.policy_counts.get(t.name, 0),
                    "source": t.source_file,
                }
            )
        return {
            "migration_files": self.migration_files[:30],
            "tables": tables,
            "indexes": [
                {"table": i.table, "columns": i.columns, "unique": i.unique} for i in self.indexes[:60]
            ],
            "unindexed_foreign_keys": [f"{t}.{c} -> {r}" for t, c, r in self.unindexed_foreign_keys()],
            "tables_without_rls": self.tables_without_rls(),
            "orm_models": self.orm_models[:60],
            "supabase_typed_tables": self.typed_tables[:60],
            "client_data_access": {k: v[:6] for k, v in list(self.data_access.items())[:40]},
            "rpc_calls": {k: v[:6] for k, v in list(self.rpc_calls.items())[:20]},
        }


# ---------------------------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------------------------
def _split_ident(raw: str) -> tuple[str | None, str]:
    parts = [p.strip() for p in raw.replace('"', "").split(".")]
    return (parts[0].lower() if len(parts) > 1 else None), parts[-1].lower()


def _strip_sql_noise(sql: str) -> str:
    """Remove function bodies, comments and string literals so they can't confuse the parser."""
    sql = re.sub(r"\$(\w*)\$.*?\$\1\$", " ", sql, flags=re.S)  # dollar-quoted bodies ($$ ... $$)
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.S)
    sql = re.sub(r"--[^\n]*", " ", sql)
    sql = re.sub(r"'(?:[^']|'')*'", "''", sql)
    return sql


def _match_paren(text: str, open_idx: int) -> int:
    depth = 0
    for i in range(open_idx, len(text)):
        if text[i] == "(":
            depth += 1
        elif text[i] == ")":
            depth -= 1
            if depth == 0:
                return i
    return -1


def _split_top_level(text: str) -> list[str]:
    parts, depth, start = [], 0, 0
    for i, ch in enumerate(text):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            parts.append(text[start:i])
            start = i + 1
    parts.append(text[start:])
    return [p.strip() for p in parts if p.strip()]


def _clean_col(expr: str) -> str:
    expr = expr.strip()
    if "(" in expr:  # expression index, e.g. lower(email)
        return re.sub(r"\s+", "", expr).lower()
    return expr.split()[0].strip('"').lower()


def _cols_in_parens(text: str) -> list[str]:
    start = text.find("(")
    end = _match_paren(text, start) if start >= 0 else -1
    if start < 0 or end < 0:
        return []
    return [_clean_col(c) for c in _split_top_level(text[start + 1 : end])]


def _apply_column_def(table: TableInfo, element: str) -> None:
    parts = element.split(None, 1)
    col = parts[0].strip('"').lower()
    rest = parts[1] if len(parts) > 1 else ""
    if col not in table.columns:
        table.columns.append(col)
    if re.search(r"\bprimary\s+key\b", rest, re.I):
        table.primary_key = [col]
    if re.search(r"\bunique\b", rest, re.I):
        table.unique_leading.add(col)
    ref = _REFERENCES_RE.search(rest)
    if ref:
        table.foreign_keys.append((col, _split_ident(ref.group("ref"))[1]))


def _apply_table_element(table: TableInfo, element: str) -> None:
    element = _CONSTRAINT_PREFIX_RE.sub("", element.strip())
    low = element.lower()
    if low.startswith("primary key"):
        table.primary_key = _cols_in_parens(element)
    elif low.startswith("foreign key"):
        m = _FK_CONSTRAINT_RE.match(element)
        if m:
            cols = [_clean_col(c) for c in m.group("cols").split(",")]
            table.foreign_keys.append((cols[0], _split_ident(m.group("ref"))[1]))
    elif low.startswith("unique"):
        cols = _cols_in_parens(element)
        if cols:
            table.unique_leading.add(cols[0])
    elif low.startswith(("check", "exclude", "like")):
        return
    else:
        _apply_column_def(table, element)


def _get_table(schema: DatabaseSchema, raw_name: str, source: str) -> TableInfo:
    sch, name = _split_ident(raw_name)
    if name not in schema.tables:
        schema.tables[name] = TableInfo(name=name, schema=sch, source_file=source)
    return schema.tables[name]


def _parse_sql(schema: DatabaseSchema, f: SourceFile) -> None:
    sql = _strip_sql_noise(f.content)

    for m in _CREATE_TABLE_RE.finditer(sql):
        open_idx = m.end() - 1
        close_idx = _match_paren(sql, open_idx)
        if close_idx < 0:
            continue
        table = _get_table(schema, m.group("name"), f.path)
        for element in _split_top_level(sql[open_idx + 1 : close_idx]):
            _apply_table_element(table, element)

    for m in _ALTER_TABLE_RE.finditer(sql):
        sch, name = _split_ident(m.group("name"))
        for action in _split_top_level(m.group("body")):
            low = action.lower()
            if re.match(r"(enable|force)\s+row\s+level\s+security", low):
                schema.rls_enabled.add(name)
            elif re.match(r"disable\s+row\s+level\s+security", low):
                schema.rls_enabled.discard(name)
            elif name in schema.tables and low.startswith("add"):
                body = re.sub(r"^add\s+", "", action, flags=re.I)
                if re.match(r"(constraint\s|primary\s+key|foreign\s+key|unique)", body, re.I):
                    _apply_table_element(schema.tables[name], body)
                else:
                    body = re.sub(r"^column\s+(if\s+not\s+exists\s+)?", "", body, flags=re.I)
                    _apply_column_def(schema.tables[name], body)

    for m in _CREATE_INDEX_RE.finditer(sql):
        open_idx = m.end() - 1
        close_idx = _match_paren(sql, open_idx)
        if close_idx < 0:
            continue
        cols = [_clean_col(c) for c in _split_top_level(sql[open_idx + 1 : close_idx])]
        if cols:
            schema.indexes.append(
                IndexInfo(
                    name=m.group("name").strip('"') if m.group("name") else None,
                    table=_split_ident(m.group("table"))[1],
                    leading_column=cols[0],
                    columns=cols,
                    unique=bool(m.group("unique")),
                    source_file=f.path,
                )
            )

    for m in _CREATE_POLICY_RE.finditer(sql):
        schema.policy_counts[_split_ident(m.group("table"))[1]] += 1


def analyse_database(files: list[SourceFile]) -> DatabaseSchema:
    schema = DatabaseSchema()
    # Migrations are applied in filename order (timestamps), so parse them in that order.
    for f in sorted((f for f in files if f.ext == ".sql"), key=lambda f: f.path):
        schema.migration_files.append(f.path)
        _parse_sql(schema, f)

    for f in files:
        if f.name == "schema.prisma":
            schema.orm_models += _PRISMA_MODEL_RE.findall(f.content)
        elif f.ext in (".ts", ".js") and "Table(" in f.content:
            schema.orm_models += _DRIZZLE_TABLE_RE.findall(f.content)

        if f.ext == ".ts" and "supabase" in f.path.lower() and "types" in f.name.lower() and "Tables" in f.content:
            for t in _SUPABASE_TYPES_TABLE_RE.findall(f.content):
                if t not in schema.typed_tables:
                    schema.typed_tables.append(t)

        if f.ext in (".ts", ".tsx", ".js", ".jsx", ".vue", ".svelte") and "supabase" in f.content.lower():
            for m in _SUPABASE_FROM_RE.finditer(f.content):
                if "storage" in f.content[max(0, m.start() - 24) : m.start()]:
                    continue  # supabase.storage.from('bucket') is a storage bucket, not a table
                table = m.group(1)
                schema.data_access.setdefault(table, [])
                if f.path not in schema.data_access[table]:
                    schema.data_access[table].append(f.path)
            for fn in _SUPABASE_RPC_RE.findall(f.content):
                schema.rpc_calls.setdefault(fn, [])
                if f.path not in schema.rpc_calls[fn]:
                    schema.rpc_calls[fn].append(f.path)

    schema.orm_models = list(dict.fromkeys(schema.orm_models))
    return schema
