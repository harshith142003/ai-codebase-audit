"""Dependency manifests -> dependency lists, framework detection, AI-builder fingerprinting."""

from __future__ import annotations

import json
import re
import tomllib
from dataclasses import dataclass, field

from app.analysis.archive import SourceFile


@dataclass
class Manifest:
    path: str
    ecosystem: str  # "npm" | "python"
    dependencies: dict[str, str] = field(default_factory=dict)
    dev_dependencies: dict[str, str] = field(default_factory=dict)
    scripts: dict[str, str] = field(default_factory=dict)

    @property
    def all_names(self) -> set[str]:
        return {n.lower() for n in (*self.dependencies, *self.dev_dependencies)}


# (dependency name, label) — order defines display order.
FRAMEWORK_SIGNATURES: list[tuple[str, str]] = [
    ("next", "Next.js"), ("nuxt", "Nuxt"), ("@sveltejs/kit", "SvelteKit"), ("@remix-run/react", "Remix"),
    ("astro", "Astro"), ("react", "React"), ("vue", "Vue"), ("svelte", "Svelte"), ("vite", "Vite"),
    ("express", "Express"), ("hono", "Hono"), ("fastify", "Fastify"), ("@nestjs/core", "NestJS"),
    ("@supabase/supabase-js", "Supabase"), ("supabase", "Supabase"), ("firebase", "Firebase"),
    ("@prisma/client", "Prisma"), ("prisma", "Prisma"), ("drizzle-orm", "Drizzle ORM"), ("mongoose", "Mongoose"),
    ("@tanstack/react-query", "TanStack Query"), ("react-router-dom", "React Router"),
    ("tailwindcss", "Tailwind CSS"), ("zod", "Zod"), ("react-hook-form", "React Hook Form"),
    ("stripe", "Stripe"), ("@clerk/nextjs", "Clerk"), ("next-auth", "NextAuth"), ("openai", "OpenAI SDK"),
    ("fastapi", "FastAPI"), ("django", "Django"), ("flask", "Flask"), ("sqlalchemy", "SQLAlchemy"),
]

_REQ_NAME_RE = re.compile(r"^\s*([A-Za-z0-9][A-Za-z0-9._-]*)")


def _parse_package_json(f: SourceFile) -> Manifest | None:
    try:
        data = json.loads(f.content)
    except (json.JSONDecodeError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    as_dict = lambda v: {str(k): str(x) for k, x in v.items()} if isinstance(v, dict) else {}  # noqa: E731
    return Manifest(
        path=f.path,
        ecosystem="npm",
        dependencies=as_dict(data.get("dependencies")),
        dev_dependencies=as_dict(data.get("devDependencies")),
        scripts=as_dict(data.get("scripts")),
    )


def _parse_requirements(f: SourceFile) -> Manifest:
    deps: dict[str, str] = {}
    for line in f.content.splitlines():
        line = line.split("#", 1)[0].strip()
        if not line or line.startswith(("-", "git+", "http")):
            continue
        m = _REQ_NAME_RE.match(line)
        if m:
            deps[m.group(1).lower()] = line[m.end():].strip() or "*"
    return Manifest(path=f.path, ecosystem="python", dependencies=deps)


def _parse_pyproject(f: SourceFile) -> Manifest | None:
    try:
        data = tomllib.loads(f.content)
    except tomllib.TOMLDecodeError:
        return None
    deps: dict[str, str] = {}
    for spec in data.get("project", {}).get("dependencies", []) or []:
        m = _REQ_NAME_RE.match(str(spec))
        if m:
            deps[m.group(1).lower()] = str(spec)[m.end():].strip() or "*"
    poetry = data.get("tool", {}).get("poetry", {}).get("dependencies", {}) or {}
    for name, spec in poetry.items():
        if name.lower() != "python":
            deps[name.lower()] = str(spec)
    return Manifest(path=f.path, ecosystem="python", dependencies=deps) if deps else None


def parse_manifests(files: list[SourceFile]) -> list[Manifest]:
    manifests: list[Manifest] = []
    for f in files:
        name = f.name.lower()
        m: Manifest | None = None
        if name == "package.json":
            m = _parse_package_json(f)
        elif name.startswith("requirements") and name.endswith(".txt"):
            m = _parse_requirements(f)
        elif name == "pyproject.toml":
            m = _parse_pyproject(f)
        if m:
            manifests.append(m)
    # Root manifests first: they describe the main app in a monorepo.
    return sorted(manifests, key=lambda m: (m.path.count("/"), m.path))


def detect_frameworks(manifests: list[Manifest]) -> list[str]:
    names: set[str] = set().union(*(m.all_names for m in manifests)) if manifests else set()
    found: list[str] = []
    for dep, label in FRAMEWORK_SIGNATURES:
        if dep in names and label not in found:
            found.append(label)
    if any(n.startswith("@radix-ui/") for n in names):
        found.append("Radix UI / shadcn")
    return found


def detect_generator(manifests: list[Manifest], all_paths: list[str], files: list[SourceFile]) -> str | None:
    """Best-effort fingerprint of the AI app builder that produced the code."""
    names: set[str] = set().union(*(m.all_names for m in manifests)) if manifests else set()
    if "lovable-tagger" in names:
        return "Lovable"
    if any(p.startswith(".bolt/") for p in all_paths):
        return "Bolt"
    readme = next((f.content.lower() for f in files if f.path.lower() == "readme.md"), "")
    if "lovable.dev" in readme or "lovable.app" in readme:
        return "Lovable"
    if "v0.dev" in readme or "v0.app" in readme:
        return "v0"
    if "bolt.new" in readme:
        return "Bolt"
    return None
