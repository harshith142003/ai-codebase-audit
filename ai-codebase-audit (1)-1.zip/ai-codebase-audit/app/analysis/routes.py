"""Extract server-side API routes.

* Python (FastAPI / Flask / Starlette-style decorators) is parsed with the
  standard-library `ast` module, so we read real decorator calls rather than
  pattern-matching text.
* JS/TS uses file-system conventions (Next.js app & pages routers, SvelteKit,
  Supabase Edge Functions) plus a guarded regex for Express/Hono/Fastify.
  A full TS parser (tree-sitter) would be more precise but adds native build
  dependencies; for scoping an engagement, this is accurate enough.
"""

from __future__ import annotations

import ast
import re
from dataclasses import asdict, dataclass

from app.analysis.archive import SourceFile

HTTP_METHODS = ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS")
JS_EXTS = (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs")

_EXPORTED_METHOD_RE = re.compile(
    r"export\s+(?:async\s+function|function|const|let)\s+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)\b"
)
_EXPRESS_RE = re.compile(
    r"\b(?:app|router|server|routes|api_router)\s*\.\s*(get|post|put|patch|delete|all|options)\s*\(\s*"
    r"(['\"`])(/[^'\"`]*)\2"
)
_DJANGO_PATH_RE = re.compile(r"\b(?:re_)?path\(\s*r?['\"]([^'\"]*)['\"]")
_PY_ROUTE_ATTRS = {"get", "post", "put", "patch", "delete", "options", "head", "route", "api_route", "websocket"}


@dataclass(frozen=True)
class ApiRoute:
    method: str
    path: str
    file: str
    kind: str

    def as_dict(self) -> dict[str, str]:
        return asdict(self)


def _segments_to_path(segments: list[str]) -> str:
    cleaned = [s for s in segments if not (s.startswith("(") and s.endswith(")")) and not s.startswith("@")]
    return "/" + "/".join(cleaned)


def _js_methods(content: str) -> list[str]:
    return sorted(set(_EXPORTED_METHOD_RE.findall(content))) or ["ANY"]


def _next_app_route(f: SourceFile) -> list[ApiRoute]:
    parts = f.path.split("/")
    if not parts[-1].startswith("route.") or "app" not in parts[:-1]:
        return []
    idx = len(parts) - 2 - parts[:-1][::-1].index("app")
    path = _segments_to_path(parts[idx + 1 : -1])
    return [ApiRoute(m, path, f.path, "nextjs-app-router") for m in _js_methods(f.content)]


def _next_pages_route(f: SourceFile) -> list[ApiRoute]:
    parts = f.path.split("/")
    for i in range(len(parts) - 2):
        if parts[i] == "pages" and parts[i + 1] == "api":
            segs = parts[i + 1 :]
            segs[-1] = segs[-1].rsplit(".", 1)[0]
            if segs[-1] == "index":
                segs = segs[:-1]
            return [ApiRoute("ANY", "/" + "/".join(segs), f.path, "nextjs-pages-api")]
    return []


def _sveltekit_route(f: SourceFile) -> list[ApiRoute]:
    parts = f.path.split("/")
    if not parts[-1].startswith("+server.") or "routes" not in parts:
        return []
    idx = parts.index("routes")
    return [ApiRoute(m, _segments_to_path(parts[idx + 1 : -1]), f.path, "sveltekit") for m in _js_methods(f.content)]


def _edge_function(f: SourceFile) -> list[ApiRoute]:
    parts = f.path.split("/")
    if len(parts) >= 4 and parts[-4:-2] == ["supabase", "functions"] and parts[-1].startswith("index."):
        name = parts[-2]
        if not name.startswith("_"):
            return [ApiRoute("ANY", f"/functions/v1/{name}", f.path, "supabase-edge-function")]
    return []


def _express_routes(f: SourceFile) -> list[ApiRoute]:
    content = f.content
    # Guard against HTTP *clients* (axios.get('/x')): only scan files that create a server.
    if not re.search(r"\b(express|hono|fastify|koa)\b|Router\(\)", content):
        return []
    return [
        ApiRoute(method.upper() if method != "all" else "ANY", path, f.path, "express-style")
        for method, _, path in _EXPRESS_RE.findall(content)
    ]


def _python_routes(f: SourceFile) -> list[ApiRoute]:
    try:
        tree = ast.parse(f.content, filename=f.path)
    except (SyntaxError, ValueError):
        return []
    routes: list[ApiRoute] = []
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for dec in node.decorator_list:
            if not (isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute)):
                continue
            attr = dec.func.attr
            if attr not in _PY_ROUTE_ATTRS or not dec.args:
                continue
            first = dec.args[0]
            if not (isinstance(first, ast.Constant) and isinstance(first.value, str) and first.value.startswith("/")):
                continue
            methods = [attr.upper()]
            if attr in {"route", "api_route"}:
                methods = ["GET"]
                for kw in dec.keywords:
                    if kw.arg == "methods" and isinstance(kw.value, (ast.List, ast.Tuple, ast.Set)):
                        methods = [
                            e.value.upper() for e in kw.value.elts
                            if isinstance(e, ast.Constant) and isinstance(e.value, str)
                        ] or methods
            routes.extend(ApiRoute(m, first.value, f.path, "python-decorator") for m in methods)
    return routes


def _django_routes(f: SourceFile) -> list[ApiRoute]:
    if f.name != "urls.py":
        return []
    return [ApiRoute("ANY", "/" + p.lstrip("^/"), f.path, "django-urls") for p in _DJANGO_PATH_RE.findall(f.content)]


def extract_routes(files: list[SourceFile]) -> list[ApiRoute]:
    routes: list[ApiRoute] = []
    for f in files:
        if f.ext in JS_EXTS:
            found = _next_app_route(f) or _next_pages_route(f) or _sveltekit_route(f) or _edge_function(f)
            routes.extend(found or _express_routes(f))
        elif f.ext == ".py":
            routes.extend(_python_routes(f))
            routes.extend(_django_routes(f))
    unique = {(r.method, r.path, r.file): r for r in routes}
    return sorted(unique.values(), key=lambda r: (r.path, r.method))
