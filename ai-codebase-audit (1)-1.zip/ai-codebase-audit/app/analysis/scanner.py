"""Turn raw archive bytes into a structured `ScanResult` (pure, CPU-bound, no I/O)."""

from __future__ import annotations

from dataclasses import dataclass, field

from app.analysis import checks
from app.analysis.archive import ArchiveContents, SourceFile, read_archive, render_tree
from app.analysis.checks import StaticFinding
from app.analysis.db_schema import DatabaseSchema, analyse_database
from app.analysis.manifests import Manifest, detect_frameworks, detect_generator, parse_manifests
from app.analysis.routes import ApiRoute, extract_routes
from app.analysis.secrets import SecretHit, scan_secrets

CODE_EXTS = (".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs", ".py", ".vue", ".svelte", ".go", ".rb", ".php", ".java")


@dataclass(frozen=True)
class ScanLimits:
    max_file_bytes: int
    max_files: int
    max_total_bytes: int


@dataclass
class ScanResult:
    archive: ArchiveContents
    manifests: list[Manifest]
    frameworks: list[str]
    generator: str | None
    routes: list[ApiRoute]
    database: DatabaseSchema
    secret_hits: list[SecretHit]
    env_files: list[str]
    test_files: list[str]
    largest_files: list[tuple[str, int]]
    tree: str
    static_findings: list[StaticFinding] = field(default_factory=list)

    @property
    def files(self) -> list[SourceFile]:
        return self.archive.files

    @property
    def code_file_count(self) -> int:
        return sum(1 for f in self.files if f.ext in CODE_EXTS)

    def known_paths(self) -> set[str]:
        return set(self.archive.all_paths)

    def structure_summary(self) -> dict[str, object]:
        """JSON-serialisable snapshot: stored in `audit_runs.structure` and sent to the LLM."""
        return {
            "generator": self.generator,
            "frameworks": self.frameworks,
            "file_stats": {**self.archive.stats.as_dict(), "code_files": self.code_file_count,
                           "test_files": len(self.test_files)},
            "directory_tree": self.tree,
            "manifests": [
                {
                    "path": m.path,
                    "ecosystem": m.ecosystem,
                    "dependencies": dict(list(m.dependencies.items())[:60]),
                    "dev_dependencies": dict(list(m.dev_dependencies.items())[:40]),
                    "scripts": dict(list(m.scripts.items())[:15]),
                }
                for m in self.manifests[:5]
            ],
            "api_routes": [r.as_dict() for r in self.routes[:80]],
            "database": self.database.summary(),
            "largest_source_files": [{"path": p, "lines": n} for p, n in self.largest_files],
            "committed_env_files": self.env_files,
            "secrets_detected": [
                {"kind": h.kind, "file": h.file, "line": h.line, "severity": h.severity.value} for h in self.secret_hits[:40]
            ],
            "static_findings": [
                {"severity": f.severity.value, "category": f.category.value, "title": f.title}
                for f in self.static_findings
            ],
        }


    def llm_summary(self, scale: float = 1.0) -> dict[str, object]:
        """Compact variant of `structure_summary` for the prompt (strings instead of objects)."""
        n = lambda base: max(3, int(base * scale))  # noqa: E731
        stats = self.archive.stats
        return {
            "generator": self.generator,
            "frameworks": self.frameworks,
            "files": {"analysed": stats.kept_files, "skipped": stats.skipped_total, "code": self.code_file_count,
                      "tests": len(self.test_files), "truncated": stats.truncated},
            "directory_tree": "\n".join(self.tree.splitlines()[: n(80)]),
            "manifests": {
                m.path: sorted(f"{k}@{v}" for k, v in {**m.dependencies, **m.dev_dependencies}.items())[: n(50)]
                for m in self.manifests[: n(4)]
            },
            "api_routes": [f"{r.method} {r.path} ({r.file})" for r in self.routes[: n(50)]],
            "api_routes_total": len(self.routes),
            "database": self.database.compact_summary(scale),
            "largest_source_files": [f"{p} ({lines} lines)" for p, lines in self.largest_files],
            "committed_env_files": self.env_files,
            "secrets_detected": [f"{h.kind} @ {h.file}:{h.line} [{h.severity.value}]" for h in self.secret_hits[: n(30)]],
            "static_findings": [f"[{f.severity.value}] {f.category.value}: {f.title}" for f in self.static_findings],
        }


def scan_archive(data: bytes, limits: ScanLimits) -> ScanResult:
    archive = read_archive(
        data,
        max_file_bytes=limits.max_file_bytes,
        max_files=limits.max_files,
        max_total_bytes=limits.max_total_bytes,
    )
    files = archive.files

    manifests = parse_manifests(files)
    frameworks = detect_frameworks(manifests)
    database = analyse_database(files)
    secret_hits = scan_secrets(files)
    env_files = checks.find_env_files(files)
    test_files = checks.find_test_files(files)
    code_files = [f for f in files if f.ext in CODE_EXTS and "/components/ui/" not in f"/{f.path}"]

    result = ScanResult(
        archive=archive,
        manifests=manifests,
        frameworks=frameworks,
        generator=detect_generator(manifests, archive.all_paths, files),
        routes=extract_routes(files),
        database=database,
        secret_hits=secret_hits,
        env_files=[f.path for f in env_files],
        test_files=test_files,
        largest_files=sorted(((f.path, f.line_count) for f in code_files), key=lambda x: -x[1])[:10],
        tree=render_tree(archive.all_paths),
    )
    result.static_findings = checks.sort_findings(
        [
            *checks.check_secrets(secret_hits),
            *checks.check_env_files(env_files),
            *checks.check_client_privileged_env(files),
            *checks.check_database(database, frameworks),
            *checks.check_xss(files, manifests),
            *checks.check_tests(test_files, result.code_file_count),
        ]
    )
    return result
