"""Hardcoded-secret detection and redaction.

Two jobs:
1. Find secrets deterministically (regex + JWT payload decoding). Decoding the
   JWT lets us distinguish a Supabase *anon* key (public by design) from a
   *service_role* key (full database bypass) — a distinction pure regex can't make.
2. Redact every detected value before any code is sent to a third-party LLM.
   We should never forward a client's live credentials to another vendor.
"""

from __future__ import annotations

import base64
import json
import re
from dataclasses import dataclass

from app.analysis.archive import SourceFile
from app.models.enums import Severity


@dataclass(frozen=True)
class SecretHit:
    file: str
    line: int
    kind: str
    label: str
    severity: Severity
    preview: str
    start: int
    end: int


# (kind, label, severity, pattern). Specific patterns run before the generic one.
_PATTERNS: list[tuple[str, str, Severity, re.Pattern[str]]] = [
    ("private_key", "Private key block", Severity.CRITICAL,
     re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----")),
    ("aws_access_key", "AWS access key ID", Severity.CRITICAL, re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("stripe_live_secret", "Stripe live secret key", Severity.CRITICAL,
     re.compile(r"\b(?:sk|rk)_live_[0-9A-Za-z]{20,}\b")),
    ("stripe_test_secret", "Stripe test secret key", Severity.MEDIUM, re.compile(r"\bsk_test_[0-9A-Za-z]{20,}\b")),
    ("supabase_secret_key", "Supabase secret API key", Severity.CRITICAL,
     re.compile(r"\bsb_secret_[0-9A-Za-z_-]{20,}\b")),
    ("supabase_publishable_key", "Supabase publishable key", Severity.INFO,
     re.compile(r"\bsb_publishable_[0-9A-Za-z_-]{20,}\b")),
    ("llm_api_key", "LLM provider API key (OpenAI/Anthropic-style)", Severity.HIGH,
     re.compile(r"\bsk-(?:proj-|ant-|svcacct-|admin-)?[A-Za-z0-9_-]{24,}\b")),
    ("groq_api_key", "Groq API key", Severity.HIGH, re.compile(r"\bgsk_[A-Za-z0-9]{20,}\b")),
    ("github_token", "GitHub token", Severity.HIGH,
     re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{36,}|github_pat_[A-Za-z0-9_]{22,})\b")),
    ("slack_token", "Slack token", Severity.HIGH, re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}\b")),
    ("google_api_key", "Google API key", Severity.MEDIUM, re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("jwt", "JSON Web Token", Severity.MEDIUM,
     re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}")),
]

_GENERIC_RE = re.compile(
    r"(?i)\b([A-Za-z0-9_]*(?:secret|password|passwd|pwd|api[_-]?key|access[_-]?token|auth[_-]?token|private[_-]?key)"
    r"[A-Za-z0-9_]*)\s*[:=]\s*['\"]([^'\"\s]{12,})['\"]"
)
_PLACEHOLDER_HINTS = (
    "your", "example", "xxxx", "<", ">", "${", "{{", "changeme", "change_me", "placeholder", "dummy",
    "redacted", "process.env", "import.meta", "os.environ", "****", "todo", "insert", "replace",
)
_TEMPLATE_FILE_RE = re.compile(r"\.env\.(example|sample|template|dist)$|\.example$", re.I)
_TESTLIKE_PATH_RE = re.compile(r"(^|/)(tests?|__tests__|spec|fixtures?|mocks?|examples?|docs?)/|\.(test|spec)\.", re.I)


def _redact_preview(value: str) -> str:
    return f"{value[:6]}…[{len(value)} chars]" if len(value) > 10 else "[redacted]"


def _jwt_payload(token: str) -> dict[str, object] | None:
    try:
        segment = token.split(".")[1]
        segment += "=" * (-len(segment) % 4)
        data = json.loads(base64.urlsafe_b64decode(segment))
        return data if isinstance(data, dict) else None
    except (IndexError, ValueError, UnicodeDecodeError):
        return None


def _classify_jwt(token: str) -> tuple[str, str, Severity]:
    payload = _jwt_payload(token) or {}
    role = str(payload.get("role", "")).lower()
    issuer = str(payload.get("iss", "")).lower()
    if role == "service_role":
        return "supabase_service_role_key", "Supabase service_role key (bypasses RLS)", Severity.CRITICAL
    if role == "anon" or (issuer == "supabase" and role in ("", "authenticated")):
        return "supabase_anon_key", "Supabase anon key (public by design)", Severity.INFO
    return "jwt", "Hardcoded JSON Web Token", Severity.MEDIUM


def _is_placeholder(value: str) -> bool:
    low = value.lower()
    return any(h in low for h in _PLACEHOLDER_HINTS) or len(set(value)) <= 3


def scan_secrets(files: list[SourceFile]) -> list[SecretHit]:
    hits: list[SecretHit] = []
    for f in files:
        if _TEMPLATE_FILE_RE.search(f.path):
            continue
        content = f.content
        spans: list[tuple[int, int]] = []

        def add(kind: str, label: str, severity: Severity, start: int, end: int) -> None:
            if any(s <= start < e or s < end <= e for s, e in spans):
                return
            spans.append((start, end))
            value = content[start:end]
            hits.append(
                SecretHit(
                    file=f.path,
                    line=content.count("\n", 0, start) + 1,
                    kind=kind,
                    label=label,
                    severity=severity,
                    preview=_redact_preview(value),
                    start=start,
                    end=end,
                )
            )

        for kind, label, severity, pattern in _PATTERNS:
            for m in pattern.finditer(content):
                if kind == "jwt":
                    kind_, label_, severity_ = _classify_jwt(m.group(0))
                    add(kind_, label_, severity_, m.start(), m.end())
                else:
                    add(kind, label, severity, m.start(), m.end())

        if f.ext != ".md" and not _TESTLIKE_PATH_RE.search(f.path):
            for m in _GENERIC_RE.finditer(content):
                name, value = m.group(1), m.group(2)
                if _is_placeholder(value) or any(p in name.lower() for p in ("public", "publishable", "anon")):
                    continue
                add("generic_secret", f"Hardcoded credential in `{name}`", Severity.HIGH, m.start(2), m.end(2))
    return hits


def redact(content: str, hits: list[SecretHit]) -> str:
    """Replace each detected secret value with a typed placeholder (spans processed right-to-left)."""
    for hit in sorted(hits, key=lambda h: h.start, reverse=True):
        content = f"{content[: hit.start]}[REDACTED:{hit.kind}]{content[hit.end :]}"
    return content
