"""Audit endpoints: submit (GitHub URL or ZIP), poll, list, fetch Markdown report."""

from __future__ import annotations

from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, File, HTTPException, Query, Request, UploadFile, status
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse, Response

from app.dependencies import get_audit_service, require_api_key
from app.errors import IngestError
from app.models.api import AuditAccepted, AuditDetail, AuditList, AuditSummary, GitHubAuditRequest
from app.models.enums import AuditStatus
from app.services.audit_service import AuditJob, AuditService

router = APIRouter(prefix="/audits", tags=["audits"], dependencies=[Depends(require_api_key)])

_WAIT_HELP = "Run the audit inline and return the finished result (handy for demos; can take 20-90s)."


def _urls(request: Request, audit_id: str) -> tuple[str, str]:
    base = str(request.base_url).rstrip("/")
    return f"{base}/audits/{audit_id}", f"{base}/audits/{audit_id}/report"


async def _detail(service: AuditService, request: Request, audit_id: str) -> AuditDetail:
    run = await service.repo.get_audit(audit_id)
    if not run:
        raise HTTPException(status_code=404, detail="Audit not found.")
    findings = await service.repo.get_findings(audit_id) if run["status"] == AuditStatus.COMPLETED else []
    return AuditDetail.from_rows(run, findings, report_url=_urls(request, audit_id)[1])


async def _dispatch(
    run: dict, job: AuditJob, wait: bool, service: AuditService, background: BackgroundTasks, request: Request
) -> AuditAccepted | JSONResponse:
    if wait:
        await service.execute(job)
        detail = await _detail(service, request, job.audit_id)
        return JSONResponse(status_code=200, content=jsonable_encoder(detail))
    background.add_task(service.execute, job)
    status_url, report_url = _urls(request, job.audit_id)
    return AuditAccepted(
        audit_id=run["id"],
        status=AuditStatus(run["status"]),
        repository=job.repository_name,
        status_url=status_url,
        report_url=report_url,
    )


@router.post(
    "",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=AuditAccepted,
    responses={200: {"model": AuditDetail, "description": "Returned when wait=true"}},
    summary="Audit a public GitHub repository",
)
async def create_github_audit(
    payload: GitHubAuditRequest,
    request: Request,
    background: BackgroundTasks,
    wait: bool = Query(False, description=_WAIT_HELP),
    service: AuditService = Depends(get_audit_service),
):
    run, job = await service.submit_github(payload)
    return await _dispatch(run, job, wait, service, background, request)


@router.post(
    "/upload",
    status_code=status.HTTP_202_ACCEPTED,
    response_model=AuditAccepted,
    responses={200: {"model": AuditDetail, "description": "Returned when wait=true"}},
    summary="Audit an uploaded ZIP of a project",
)
async def create_upload_audit(
    request: Request,
    background: BackgroundTasks,
    file: UploadFile = File(..., description="ZIP archive of the project source"),
    wait: bool = Query(False, description=_WAIT_HELP),
    service: AuditService = Depends(get_audit_service),
):
    max_bytes = service.settings.max_archive_bytes
    buffer = bytearray()
    while chunk := await file.read(1024 * 1024):
        buffer.extend(chunk)
        if len(buffer) > max_bytes:
            raise IngestError(f"Upload exceeds the {service.settings.max_archive_mb} MB limit.", http_status=413)
    run, job = await service.submit_upload(file.filename or "upload.zip", bytes(buffer))
    return await _dispatch(run, job, wait, service, background, request)


@router.get("", response_model=AuditList, summary="List audits (filter by status, repository, date)")
async def list_audits(
    status_filter: AuditStatus | None = Query(None, alias="status"),
    repository: str | None = Query(None, description="Exact repository name, e.g. owner/repo", max_length=200),
    created_after: datetime | None = Query(None),
    created_before: datetime | None = Query(None),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
    service: AuditService = Depends(get_audit_service),
) -> AuditList:
    as_utc = lambda d: d.replace(tzinfo=timezone.utc) if d and d.tzinfo is None else d  # noqa: E731
    rows, total = await service.repo.list_audits(
        status=status_filter.value if status_filter else None,
        repository=repository,
        created_after=as_utc(created_after),
        created_before=as_utc(created_before),
        limit=limit,
        offset=offset,
    )
    return AuditList(items=[AuditSummary.model_validate(r) for r in rows], total=total, limit=limit, offset=offset)


@router.get("/{audit_id}", response_model=AuditDetail, summary="Audit status, scores and itemised findings")
async def get_audit(audit_id: UUID, request: Request, service: AuditService = Depends(get_audit_service)) -> AuditDetail:
    return await _detail(service, request, str(audit_id))


@router.get(
    "/{audit_id}/report",
    response_class=Response,
    responses={200: {"content": {"text/markdown": {}}}},
    summary="Client-ready Markdown report",
)
async def get_report(audit_id: UUID, service: AuditService = Depends(get_audit_service)) -> Response:
    run = await service.repo.get_audit(str(audit_id))
    if not run:
        raise HTTPException(status_code=404, detail="Audit not found.")
    if run["status"] != AuditStatus.COMPLETED:
        detail = f"Audit is {run['status']}."
        if run.get("error_message"):
            detail += f" Reason: {run['error_message']}"
        raise HTTPException(status_code=409, detail=detail)
    return Response(content=run["report_markdown"], media_type="text/markdown; charset=utf-8")
