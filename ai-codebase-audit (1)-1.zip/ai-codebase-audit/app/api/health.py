"""Liveness / readiness."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request

from app import __version__
from app.config import Settings
from app.dependencies import get_settings_dep
from app.models.api import HealthOut

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthOut, summary="Service health (add ?deep=true to check the database)")
async def health(request: Request, deep: bool = Query(False), settings: Settings = Depends(get_settings_dep)) -> HealthOut:
    database = None
    if deep:
        try:
            await request.app.state.audit_service.repo.ping()
            database = "ok"
        except Exception as exc:  # noqa: BLE001
            database = f"error: {type(exc).__name__}"
    return HealthOut(
        status="ok" if database in (None, "ok") else "degraded",
        version=__version__,
        environment=settings.app_env,
        db_backend=settings.db_backend,
        llm_provider=settings.llm_provider,
        llm_model=settings.effective_llm_model,
        database=database,
    )
