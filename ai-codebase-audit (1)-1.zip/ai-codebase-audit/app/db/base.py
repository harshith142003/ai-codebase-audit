"""Data-access contract. Services depend on this interface, not on Supabase directly,
which keeps them unit-testable (see `InMemoryAuditRepository`)."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Protocol


class AuditRepository(Protocol):
    async def ping(self) -> None: ...

    async def upsert_repository(self, data: dict[str, Any]) -> dict[str, Any]:
        """Insert or update a repository keyed by its unique `source_key`."""

    async def create_audit_run(self, data: dict[str, Any]) -> dict[str, Any]: ...

    async def mark_processing(self, audit_id: str) -> None: ...

    async def complete_audit(self, audit_id: str, run: dict[str, Any], findings: list[dict[str, Any]]) -> None:
        """Atomically store findings and mark the run completed."""

    async def fail_audit(self, audit_id: str, error_message: str, duration_ms: int | None) -> None: ...

    async def get_audit(self, audit_id: str) -> dict[str, Any] | None:
        """Audit run with its repository embedded under the `repository` key."""

    async def get_findings(self, audit_id: str) -> list[dict[str, Any]]: ...

    async def list_audits(
        self,
        *,
        status: str | None,
        repository: str | None,
        created_after: datetime | None,
        created_before: datetime | None,
        limit: int,
        offset: int,
    ) -> tuple[list[dict[str, Any]], int]: ...

    async def fail_stale_runs(self, older_than: datetime, message: str) -> int: ...
