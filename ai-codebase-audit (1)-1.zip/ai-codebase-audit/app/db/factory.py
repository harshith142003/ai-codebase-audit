"""Build the configured repository implementation."""

from __future__ import annotations

from app.config import Settings
from app.db.base import AuditRepository
from app.db.memory_repo import InMemoryAuditRepository
from app.db.supabase_repo import SupabaseAuditRepository


def build_repository(settings: Settings) -> AuditRepository:
    if settings.db_backend == "memory":
        return InMemoryAuditRepository()
    assert settings.supabase_url and settings.supabase_service_role_key  # guaranteed by Settings validation
    return SupabaseAuditRepository(settings.supabase_url, settings.supabase_service_role_key.get_secret_value())
