"""In-memory implementation of the audit repository.

Used by the test-suite and for `DB_BACKEND=memory` local demos. It mirrors the
Supabase schema's behaviour (unique source_key upsert, embedded repository,
summary view, severity ordering, atomic completion) closely enough for tests.
"""

from __future__ import annotations

import copy
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from app.models.enums import SEVERITY_RANK


def _now() -> datetime:
    return datetime.now(timezone.utc)


class InMemoryAuditRepository:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self.repositories: dict[str, dict[str, Any]] = {}
        self.runs: dict[str, dict[str, Any]] = {}
        self.findings: list[dict[str, Any]] = []

    async def ping(self) -> None:
        return None

    async def upsert_repository(self, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            existing = next((r for r in self.repositories.values() if r["source_key"] == data["source_key"]), None)
            if existing:
                existing.update(data, updated_at=_now())
                return copy.deepcopy(existing)
            row = {"id": str(uuid.uuid4()), "created_at": _now(), "updated_at": _now(), **data}
            self.repositories[row["id"]] = row
            return copy.deepcopy(row)

    async def create_audit_run(self, data: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            row = {
                "id": str(uuid.uuid4()),
                "status": "queued",
                "created_at": _now(),
                "started_at": None,
                "completed_at": None,
                "detected_frameworks": [],
                "top_priorities": [],
                "findings_count": 0,
                "critical_count": 0,
                "high_count": 0,
                **data,
            }
            self.runs[row["id"]] = row
            return copy.deepcopy(row)

    async def mark_processing(self, audit_id: str) -> None:
        with self._lock:
            self.runs[audit_id].update(status="processing", started_at=_now())

    async def complete_audit(self, audit_id: str, run: dict[str, Any], findings: list[dict[str, Any]]) -> None:
        with self._lock:  # all-or-nothing, like the Postgres function
            current = self.runs.get(audit_id)
            if not current or current["status"] != "processing":
                raise RuntimeError(f"audit run {audit_id} is not in processing state")
            new_rows = [
                {"id": str(uuid.uuid4()), "audit_run_id": audit_id, "created_at": _now(), **f} for f in findings
            ]
            current.update(run, status="completed", completed_at=_now())
            self.findings.extend(new_rows)

    async def fail_audit(self, audit_id: str, error_message: str, duration_ms: int | None) -> None:
        with self._lock:
            self.runs[audit_id].update(
                status="failed", error_message=error_message[:2000], duration_ms=duration_ms, completed_at=_now()
            )

    async def get_audit(self, audit_id: str) -> dict[str, Any] | None:
        with self._lock:
            run = self.runs.get(audit_id)
            if not run:
                return None
            out = copy.deepcopy(run)
            out["repository"] = copy.deepcopy(self.repositories[run["repository_id"]])
            return out

    async def get_findings(self, audit_id: str) -> list[dict[str, Any]]:
        with self._lock:
            rows = [copy.deepcopy(f) for f in self.findings if f["audit_run_id"] == audit_id]
        return sorted(rows, key=lambda f: (SEVERITY_RANK[f["severity"]], f["created_at"]))

    async def list_audits(
        self,
        *,
        status: str | None,
        repository: str | None,
        created_after: datetime | None,
        created_before: datetime | None,
        limit: int,
        offset: int,
    ) -> tuple[list[dict[str, Any]], int]:
        with self._lock:
            rows = []
            for run in self.runs.values():
                repo = self.repositories[run["repository_id"]]
                rows.append(
                    {
                        **run,
                        "repository_name": repo["name"],
                        "repository_url": repo.get("url"),
                        "source_type": repo["source_type"],
                    }
                )
        if status:
            rows = [r for r in rows if r["status"] == status]
        if repository:
            rows = [r for r in rows if r["repository_name"] == repository.lower()]
        if created_after:
            rows = [r for r in rows if r["created_at"] >= created_after]
        if created_before:
            rows = [r for r in rows if r["created_at"] < created_before]
        rows.sort(key=lambda r: r["created_at"], reverse=True)
        return copy.deepcopy(rows[offset : offset + limit]), len(rows)

    async def fail_stale_runs(self, older_than: datetime, message: str) -> int:
        count = 0
        with self._lock:
            for run in self.runs.values():
                if run["status"] in ("queued", "processing") and run["created_at"] < older_than:
                    run.update(status="failed", error_message=message, completed_at=_now())
                    count += 1
        return count
