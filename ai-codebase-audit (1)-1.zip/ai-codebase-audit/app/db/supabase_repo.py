"""Supabase (PostgREST) implementation of the audit repository.

Notes:
* Uses the service_role key server-side only. Tables have RLS enabled with no
  policies, so the public anon key can read nothing.
* supabase-py is synchronous; calls are pushed to a worker thread so they never
  block the event loop.
* Completing an audit goes through the `complete_audit_run` Postgres function so
  findings + run status are written in ONE transaction (PostgREST runs each RPC
  call in a transaction). No half-written audits.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from datetime import datetime, timezone
from typing import Any, TypeVar

from supabase import Client, create_client

from app.errors import AuditError

T = TypeVar("T")

_RUN_WITH_REPO = (
    "*, repository:repositories(id, name, source_type, url, default_branch, description, primary_language, stars)"
)


def _iso(dt: datetime) -> str:
    return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).isoformat()


class SupabaseAuditRepository:
    def __init__(self, url: str, service_role_key: str) -> None:
        self._client: Client = create_client(url, service_role_key)

    async def _run(self, fn: Callable[[], T]) -> T:
        try:
            return await asyncio.to_thread(fn)
        except AuditError:
            raise
        except Exception as exc:  # postgrest.APIError, httpx errors, ...
            raise AuditError(f"Database error: {exc}", http_status=503) from exc

    def _t(self, name: str):  # noqa: ANN202
        return self._client.table(name)

    async def ping(self) -> None:
        await self._run(lambda: self._t("repositories").select("id").limit(1).execute())

    async def upsert_repository(self, data: dict[str, Any]) -> dict[str, Any]:
        res = await self._run(lambda: self._t("repositories").upsert(data, on_conflict="source_key").execute())
        return res.data[0]

    async def create_audit_run(self, data: dict[str, Any]) -> dict[str, Any]:
        res = await self._run(lambda: self._t("audit_runs").insert(data).execute())
        return res.data[0]

    async def mark_processing(self, audit_id: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        await self._run(
            lambda: self._t("audit_runs").update({"status": "processing", "started_at": now}).eq("id", audit_id).execute()
        )

    async def complete_audit(self, audit_id: str, run: dict[str, Any], findings: list[dict[str, Any]]) -> None:
        params = {"p_audit_id": audit_id, "p_run": run, "p_findings": findings}
        await self._run(lambda: self._client.rpc("complete_audit_run", params).execute())

    async def fail_audit(self, audit_id: str, error_message: str, duration_ms: int | None) -> None:
        update = {
            "status": "failed",
            "error_message": error_message[:2000],
            "duration_ms": duration_ms,
            "completed_at": datetime.now(timezone.utc).isoformat(),
        }
        await self._run(lambda: self._t("audit_runs").update(update).eq("id", audit_id).execute())

    async def get_audit(self, audit_id: str) -> dict[str, Any] | None:
        res = await self._run(lambda: self._t("audit_runs").select(_RUN_WITH_REPO).eq("id", audit_id).limit(1).execute())
        return res.data[0] if res.data else None

    async def get_findings(self, audit_id: str) -> list[dict[str, Any]]:
        res = await self._run(
            lambda: self._t("audit_findings")
            .select("*")
            .eq("audit_run_id", audit_id)
            .order("severity")  # enum order: critical -> info
            .order("created_at")
            .execute()
        )
        return res.data or []

    async def list_audits(
        self,
        *,
        status: str | None,
        repository: str | None,
        created_after: datetime | None,
        created_before: datetime | None,
        limit: int,
        offset: int,
    ) -> tuple[list[dict[str, Any]], int]:
        def query():  # noqa: ANN202
            q = self._t("audit_run_summaries").select("*", count="exact")
            if status:
                q = q.eq("status", status)
            if repository:
                q = q.eq("repository_name", repository.lower())
            if created_after:
                q = q.gte("created_at", _iso(created_after))
            if created_before:
                q = q.lt("created_at", _iso(created_before))
            return q.order("created_at", desc=True).range(offset, offset + limit - 1).execute()

        res = await self._run(query)
        return res.data or [], res.count or 0

    async def fail_stale_runs(self, older_than: datetime, message: str) -> int:
        update = {"status": "failed", "error_message": message, "completed_at": datetime.now(timezone.utc).isoformat()}
        res = await self._run(
            lambda: self._t("audit_runs")
            .update(update)
            .in_("status", ["queued", "processing"])
            .lt("created_at", _iso(older_than))
            .execute()
        )
        return len(res.data or [])
