"""Provider-agnostic LLM client.

Gemini, Groq, DeepSeek and OpenRouter all expose an OpenAI-compatible
`/chat/completions` endpoint, so one small httpx client covers every
cost-effective provider. Switching providers is a config change, not a code change.

Resilience:
* Exponential backoff with jitter on 429 / 5xx / network errors, honouring `Retry-After`.
* If a provider rejects an optional parameter (`response_format`, `reasoning_effort`)
  with HTTP 400, the request is retried once without the optional parameters.
"""

from __future__ import annotations

import asyncio
import logging
import random
from dataclasses import dataclass, field
from typing import Any, Protocol

import httpx

from app.config import Settings
from app.errors import LLMError

logger = logging.getLogger(__name__)

RETRYABLE_STATUS = {408, 409, 429, 500, 502, 503, 504}


@dataclass
class LLMUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0

    def __iadd__(self, other: "LLMUsage") -> "LLMUsage":
        self.prompt_tokens += other.prompt_tokens
        self.completion_tokens += other.completion_tokens
        return self


@dataclass
class LLMResponse:
    content: str
    usage: LLMUsage = field(default_factory=LLMUsage)


class LLMClient(Protocol):
    provider: str
    model: str

    async def chat(self, messages: list[dict[str, str]]) -> LLMResponse: ...


class OpenAICompatibleClient:
    def __init__(
        self,
        *,
        http: httpx.AsyncClient,
        provider: str,
        base_url: str,
        api_key: str,
        model: str,
        max_output_tokens: int,
        temperature: float = 0.1,
        reasoning_effort: str | None = None,
        timeout_seconds: float = 180.0,
        max_retries: int = 4,
    ) -> None:
        self._http = http
        self.provider = provider
        self.model = model
        self._url = f"{base_url.rstrip('/')}/chat/completions"
        self._api_key = api_key
        self._max_output_tokens = max_output_tokens
        self._temperature = temperature
        self._reasoning_effort = reasoning_effort
        self._timeout = timeout_seconds
        self._max_retries = max(1, max_retries)

    @classmethod
    def from_settings(cls, settings: Settings, http: httpx.AsyncClient) -> "OpenAICompatibleClient":
        return cls(
            http=http,
            provider=settings.llm_provider,
            base_url=settings.effective_llm_base_url,
            api_key=settings.llm_api_key.get_secret_value(),
            model=settings.effective_llm_model,
            max_output_tokens=settings.effective_max_output_tokens,
            temperature=settings.llm_temperature,
            reasoning_effort=settings.effective_reasoning_effort,
            timeout_seconds=settings.llm_timeout_seconds,
            max_retries=settings.llm_max_retries,
        )

    def _payload(self, messages: list[dict[str, str]], with_optional: bool) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "temperature": self._temperature,
            "max_tokens": self._max_output_tokens,
        }
        if with_optional:
            payload["response_format"] = {"type": "json_object"}
            if self._reasoning_effort:
                payload["reasoning_effort"] = self._reasoning_effort
        return payload

    @staticmethod
    def _retry_after(response: httpx.Response) -> float | None:
        value = response.headers.get("retry-after")
        try:
            return min(float(value), 60.0) if value else None
        except ValueError:
            return None

    async def chat(self, messages: list[dict[str, str]]) -> LLMResponse:
        headers = {"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"}
        with_optional = True
        last_error = "unknown error"

        for attempt in range(1, self._max_retries + 1):
            try:
                response = await self._http.post(
                    self._url, json=self._payload(messages, with_optional), headers=headers, timeout=self._timeout
                )
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_error = f"{type(exc).__name__}: {exc}"
                logger.warning("LLM request failed (attempt %s/%s): %s", attempt, self._max_retries, last_error)
                await self._sleep(attempt, None)
                continue

            if response.status_code == 400 and with_optional:
                logger.warning("LLM rejected optional params; retrying without them: %s", response.text[:300])
                with_optional = False
                continue
            if response.status_code in RETRYABLE_STATUS:
                last_error = f"HTTP {response.status_code}: {response.text[:300]}"
                logger.warning("LLM retryable error (attempt %s/%s): %s", attempt, self._max_retries, last_error)
                await self._sleep(attempt, self._retry_after(response))
                continue
            if response.status_code >= 400:
                hint = ""
                if response.status_code == 413:
                    hint = " (request too large for this tier: lower LLM_CONTEXT_CHAR_BUDGET)"
                elif response.status_code in (401, 403):
                    hint = " (check LLM_API_KEY)"
                raise LLMError(f"{self.provider} returned HTTP {response.status_code}{hint}: {response.text[:300]}")

            return self._parse(response)

        raise LLMError(f"{self.provider} request failed after {self._max_retries} attempts: {last_error}")

    async def _sleep(self, attempt: int, retry_after: float | None) -> None:
        delay = retry_after if retry_after is not None else min(30.0, 2.0**attempt) + random.uniform(0, 1)
        await asyncio.sleep(delay)

    def _parse(self, response: httpx.Response) -> LLMResponse:
        try:
            data = response.json()
            message = data["choices"][0]["message"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise LLMError(f"Unexpected response shape from {self.provider}: {response.text[:300]}") from exc

        content = message.get("content")
        if isinstance(content, list):  # some providers return content parts
            content = "".join(p.get("text", "") for p in content if isinstance(p, dict))
        if not content:
            finish = data["choices"][0].get("finish_reason")
            raise LLMError(f"{self.provider} returned an empty completion (finish_reason={finish}).")

        usage = data.get("usage") or {}
        return LLMResponse(
            content=content,
            usage=LLMUsage(
                prompt_tokens=int(usage.get("prompt_tokens") or 0),
                completion_tokens=int(usage.get("completion_tokens") or 0),
            ),
        )
