"""Enforce structured JSON output from any chat model.

Strategy (works across providers, unlike provider-specific strict schema modes):
1. Put the Pydantic-generated JSON Schema in the system prompt and request JSON mode.
2. Extract the JSON object from the reply (tolerating code fences / <think> blocks).
3. Validate with Pydantic.
4. On failure, send the validation errors back to the model and ask for a corrected
   object (one repair round-trip), then fail loudly if it is still invalid.
"""

from __future__ import annotations

import json
import logging
import re
from typing import TypeVar

from pydantic import BaseModel, ValidationError

from app.errors import LLMOutputError
from app.llm.client import LLMClient, LLMUsage

logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

_THINK_RE = re.compile(r"<think>.*?</think>", re.S | re.I)
_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.I)


def extract_json(text: str) -> dict:
    cleaned = _THINK_RE.sub("", text).strip()
    cleaned = _FENCE_RE.sub("", cleaned).strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        start, end = cleaned.find("{"), cleaned.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("no JSON object found in model output") from None
        data = json.loads(cleaned[start : end + 1])
    if not isinstance(data, dict):
        raise ValueError("model output is JSON but not an object")
    return data


def _describe(exc: Exception) -> str:
    if isinstance(exc, ValidationError):
        lines = [f"- {'.'.join(str(p) for p in e['loc'])}: {e['msg']}" for e in exc.errors()[:15]]
        return "\n".join(lines)
    return str(exc)


async def generate_structured(
    client: LLMClient,
    model_cls: type[T],
    *,
    system_prompt: str,
    user_prompt: str,
    max_repairs: int = 1,
) -> tuple[T, LLMUsage]:
    messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": user_prompt}]
    usage = LLMUsage()

    for attempt in range(max_repairs + 1):
        response = await client.chat(messages)
        usage += response.usage
        try:
            return model_cls.model_validate(extract_json(response.content)), usage
        except (ValueError, ValidationError) as exc:
            problem = _describe(exc)
            logger.warning("LLM output failed validation (attempt %s): %s", attempt + 1, problem)
            if attempt == max_repairs:
                raise LLMOutputError(f"LLM output failed schema validation: {problem[:500]}") from exc
            messages += [
                {"role": "assistant", "content": response.content[:20_000]},
                {
                    "role": "user",
                    "content": (
                        "Your previous reply did not match the required JSON schema:\n"
                        f"{problem}\n\nReturn ONLY the corrected JSON object, with no other text."
                    ),
                },
            ]
    raise AssertionError("unreachable")
