"""Request and response models for the public HTTP API."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import AuditStatus, EffortLevel, FindingCategory, FindingSource, Severity, SourceType

GITHUB_URL_RE = re.compile(
    r"^https?://(?:www\.)?github\.com/"
    r"(?P<owner>[A-Za-z0-9](?:[A-Za-z0-9-]{0,38}))/"
    r"(?P<repo>[A-Za-z0-9._-]+?)(?:\.git)?"
    r"(?:/tree/(?P<ref>[^?#]+?))?/?(?:[?#].*)?$"
)
REF_RE = re.compile(r"^[A-Za-z0-9._/-]{1,200}$")


# --------------------------------------------------------------------------------------------
# Requests
# --------------------------------------------------------------------------------------------
class GitHubAuditRequest(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={"examples": [{"repo_url": "https://github.com/owner/my-lovable-app", "ref": "main"}]}
    )

    repo_url: str = Field(description="Public GitHub repository URL, e.g. https://github.com/owner/repo")
    ref: str | None = Field(default=None, description="Branch, tag or commit SHA. Defaults to the default branch.")

    @field_validator("repo_url")
    @classmethod
    def _validate_url(cls, v: str) -> str:
        v = v.strip()
        if not GITHUB_URL_RE.match(v):
            raise ValueError("must be a GitHub repository URL like https://github.com/<owner>/<repo>")
        return v

    @field_validator("ref")
    @classmethod
    def _validate_ref(cls, v: str | None) -> str | None:
        if v is None or not v.strip():
            return None
        v = v.strip()
        if not REF_RE.match(v) or ".." in v:
            raise ValueError("invalid git ref")
        return v


# --------------------------------------------------------------------------------------------
# Responses
# --------------------------------------------------------------------------------------------
class AuditAccepted(BaseModel):
    audit_id: UUID
    status: AuditStatus
    repository: str
    status_url: str
    report_url: str


class RepositoryOut(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    name: str
    source_type: SourceType
    url: str | None = None
    default_branch: str | None = None
    description: str | None = None
    primary_language: str | None = None
    stars: int | None = None


class FindingOut(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    category: FindingCategory
    severity: Severity
    source: FindingSource
    title: str
    description: str
    recommendation: str | None = None
    file_path: str | None = None
    effort: EffortLevel | None = None


class CriterionOut(BaseModel):
    score: int | None = None
    summary: str | None = None


class AuditDetail(BaseModel):
    id: UUID
    status: AuditStatus
    repository: RepositoryOut
    git_ref: str | None = None
    llm_provider: str
    llm_model: str
    generator: str | None = None
    detected_frameworks: list[str] = []
    architecture: CriterionOut
    database: CriterionOut
    security: CriterionOut
    remediation_effort: EffortLevel | None = None
    remediation_rationale: str | None = None
    top_priorities: list[str] = []
    executive_summary: str | None = None
    findings_count: int = 0
    critical_count: int = 0
    high_count: int = 0
    files_scanned: int | None = None
    files_skipped: int | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    duration_ms: int | None = None
    error_message: str | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    report_url: str
    findings: list[FindingOut] = []

    @classmethod
    def from_rows(cls, run: dict[str, Any], findings: list[dict[str, Any]], report_url: str) -> "AuditDetail":
        return cls(
            **{k: v for k, v in run.items() if k in cls.model_fields and k not in {"repository", "findings"}},
            repository=RepositoryOut.model_validate(run["repository"]),
            architecture=CriterionOut(score=run.get("architecture_score"), summary=run.get("architecture_summary")),
            database=CriterionOut(score=run.get("database_score"), summary=run.get("database_summary")),
            security=CriterionOut(score=run.get("security_score"), summary=run.get("security_summary")),
            report_url=report_url,
            findings=[FindingOut.model_validate(f) for f in findings],
        )


class AuditSummary(BaseModel):
    model_config = ConfigDict(extra="ignore")

    id: UUID
    status: AuditStatus
    repository_id: UUID
    repository_name: str
    repository_url: str | None = None
    source_type: SourceType
    git_ref: str | None = None
    llm_model: str
    remediation_effort: EffortLevel | None = None
    architecture_score: int | None = None
    database_score: int | None = None
    security_score: int | None = None
    findings_count: int = 0
    critical_count: int = 0
    high_count: int = 0
    duration_ms: int | None = None
    error_message: str | None = None
    created_at: datetime
    completed_at: datetime | None = None


class AuditList(BaseModel):
    items: list[AuditSummary]
    total: int
    limit: int
    offset: int


class HealthOut(BaseModel):
    status: str
    version: str
    environment: str
    db_backend: str
    llm_provider: str
    llm_model: str
    database: str | None = None
