"""Enumerations shared by the API, the LLM schema and the database (mirrors the Postgres enums)."""

from __future__ import annotations

from enum import StrEnum


class AuditStatus(StrEnum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class SourceType(StrEnum):
    GITHUB = "github"
    ZIP = "zip"


class Severity(StrEnum):
    # Declaration order == Postgres enum order == sort order (most severe first).
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


SEVERITY_RANK: dict[str, int] = {s.value: i for i, s in enumerate(Severity)}


class FindingCategory(StrEnum):
    ARCHITECTURE = "architecture"
    DATABASE = "database"
    SECURITY = "security"


class EffortLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class FindingSource(StrEnum):
    STATIC = "static"  # deterministic checks (regex / SQL / AST)
    LLM = "llm"  # model judgement
