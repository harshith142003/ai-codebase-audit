"""Pydantic schema the LLM must return.

The JSON Schema embedded in the prompt is generated from these same models
(`AuditLLMResult.model_json_schema()`), so the prompt contract and the
validator can never drift apart.

Validators are deliberately *tolerant on shape, strict on meaning*: they fix
cosmetic deviations that open-weight models commonly produce ("High" vs "high",
"7/10", a few extra findings) instead of failing the whole audit, but anything
semantically invalid still raises and triggers a repair round-trip.
"""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator

from app.models.enums import EffortLevel, FindingCategory, Severity

MAX_LLM_FINDINGS = 25

_SEVERITY_ALIASES = {
    "crit": "critical", "severe": "critical", "blocker": "critical",
    "major": "high", "important": "high",
    "moderate": "medium", "med": "medium", "medium-high": "high", "medium high": "high",
    "minor": "low", "trivial": "low",
    "informational": "info", "information": "info", "note": "info", "none": "info",
}
_EFFORT_ALIASES = {"med": "medium", "moderate": "medium", "small": "low", "large": "high", "very high": "high"}


def _clean(value: Any) -> Any:
    return value.strip().lower().replace("_", " ") if isinstance(value, str) else value


def coerce_severity(value: Any) -> Any:
    v = _clean(value)
    return _SEVERITY_ALIASES.get(v, v) if isinstance(v, str) else v


def coerce_effort(value: Any) -> Any:
    v = _clean(value)
    return _EFFORT_ALIASES.get(v, v) if isinstance(v, str) else v


def coerce_category(value: Any) -> Any:
    v = _clean(value)
    if not isinstance(v, str):
        return v
    if "secur" in v or "auth" in v or "secret" in v:
        return FindingCategory.SECURITY.value
    if any(k in v for k in ("data", "db", "index", "schema", "sql", "query")):
        return FindingCategory.DATABASE.value
    if any(k in v for k in ("arch", "maintain", "structure", "code quality", "design", "test")):
        return FindingCategory.ARCHITECTURE.value
    return v


class LLMFinding(BaseModel):
    model_config = ConfigDict(extra="ignore")

    category: FindingCategory = Field(description="Which audit area this finding belongs to.")
    severity: Severity = Field(description="critical | high | medium | low | info")
    title: str = Field(min_length=3, max_length=160, description="Short, specific headline.")
    description: str = Field(min_length=10, description="What is wrong, where, and why it matters.")
    recommendation: str = Field(default="", description="Concrete fix the studio would implement.")
    file_path: str | None = Field(default=None, description="Most relevant file path from the excerpts, or null.")
    effort: EffortLevel = Field(default=EffortLevel.MEDIUM, description="Effort to fix this one finding.")

    _cat = field_validator("category", mode="before")(coerce_category)
    _sev = field_validator("severity", mode="before")(coerce_severity)
    _eff = field_validator("effort", mode="before")(coerce_effort)

    @field_validator("title", mode="before")
    @classmethod
    def _trim_title(cls, v: Any) -> Any:
        return v.strip()[:160] if isinstance(v, str) else v

    @field_validator("file_path", mode="before")
    @classmethod
    def _clean_path(cls, v: Any) -> Any:
        if not isinstance(v, str) or not v.strip() or v.strip().lower() in {"null", "none", "n/a"}:
            return None
        path = re.sub(r"(:\d+(-\d+)?)+$", "", v.strip())  # drop ":42" / ":10-20" line suffixes
        return path.lstrip("./").lstrip("/") or None


class CriterionAssessment(BaseModel):
    model_config = ConfigDict(extra="ignore")

    score: int = Field(ge=1, le=10, description="1 = unsafe/unmaintainable, 10 = production-ready.")
    summary: str = Field(min_length=10, description="2-4 sentence assessment grounded in the evidence.")

    @field_validator("score", mode="before")
    @classmethod
    def _coerce_score(cls, v: Any) -> Any:
        if isinstance(v, str):
            m = re.search(r"\d+(\.\d+)?", v)
            v = float(m.group()) if m else v
        if isinstance(v, float):
            v = round(v)
        if isinstance(v, int):
            return max(1, min(10, v))
        return v


class RemediationEstimate(BaseModel):
    model_config = ConfigDict(extra="ignore")

    level: EffortLevel = Field(description="Overall remediation effort: low | medium | high.")
    rationale: str = Field(min_length=20, description="Specific justification tied to the findings.")
    top_priorities: list[str] = Field(default_factory=list, description="Up to 5 fixes to do first, in order.")

    _lvl = field_validator("level", mode="before")(coerce_effort)

    @field_validator("top_priorities", mode="before")
    @classmethod
    def _limit(cls, v: Any) -> Any:
        return [str(x) for x in v][:5] if isinstance(v, list) else v


class AuditLLMResult(BaseModel):
    """The complete structured verdict returned by the LLM."""

    model_config = ConfigDict(extra="ignore")

    executive_summary: str = Field(min_length=40, description="3-5 sentences for a non-specialist client.")
    architecture: CriterionAssessment
    database: CriterionAssessment
    security: CriterionAssessment
    remediation: RemediationEstimate
    findings: list[LLMFinding] = Field(default_factory=list, description="5-20 findings, most severe first.")

    @field_validator("findings", mode="before")
    @classmethod
    def _cap(cls, v: Any) -> Any:
        return v[:MAX_LLM_FINDINGS] if isinstance(v, list) else v
