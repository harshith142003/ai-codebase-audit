"""Audit orchestration: intake -> scan -> LLM -> merge -> report -> persist.

Submission is split into two phases:
* `submit_*` runs inside the HTTP request: cheap validation (URL, GitHub
  metadata, ZIP signature) + DB rows. Bad input fails fast with a 4xx.
* `execute` runs in the background (or inline with `?wait=true`): the slow
  download, analysis and LLM call. It never raises; failures are recorded on
  the run row so clients see `status=failed` with a reason.
"""

from __future__ import annotations

import asyncio
import hashlib
import io
import logging
import re
import time
import zipfile
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from app.analysis.context import build_context
from app.analysis.scanner import ScanLimits, ScanResult, scan_archive
from app.config import Settings
from app.db.base import AuditRepository
from app.errors import AuditError, IngestError
from app.llm.client import LLMClient
from app.llm.prompts import system_prompt, user_prompt
from app.llm.structured import generate_structured
from app.models.api import GitHubAuditRequest
from app.models.enums import SEVERITY_RANK, FindingSource, SourceType
from app.models.llm import AuditLLMResult
from app.services.github import GitHubClient, RepoMetadata, parse_github_url
from app.services.report import ReportMeta, render_report

logger = logging.getLogger(__name__)


@dataclass
class AuditJob:
    audit_id: str
    repository_name: str
    repository_url: str | None
    git_ref: str | None
    load_archive: Callable[[], Awaitable[bytes]]


def merge_findings(scan: ScanResult, result: AuditLLMResult) -> list[dict[str, Any]]:
    """Static findings + LLM findings, de-duplicated, hallucinated paths dropped, sorted by severity."""
    known_paths = scan.known_paths()
    rows: list[dict[str, Any]] = [f.as_row() for f in scan.static_findings]
    seen_titles = {r["title"].strip().lower() for r in rows}

    for f in result.findings:
        if f.title.strip().lower() in seen_titles:
            continue
        seen_titles.add(f.title.strip().lower())
        path = f.file_path
        if path and path not in known_paths and not any(p.startswith(path.rstrip("/") + "/") for p in known_paths):
            logger.info("Dropping unverifiable file_path from LLM finding: %s", path)
            path = None
        rows.append(
            {
                "category": f.category.value,
                "severity": f.severity.value,
                "source": FindingSource.LLM.value,
                "title": f.title,
                "description": f.description,
                "recommendation": f.recommendation or None,
                "file_path": path,
                "effort": f.effort.value,
            }
        )
    # Stable sort: within a severity, deterministic findings come first.
    return sorted(rows, key=lambda r: SEVERITY_RANK[r["severity"]])


def _public_error(exc: Exception) -> str:
    if isinstance(exc, AuditError):
        return exc.message[:1000]
    return "Internal error while running the audit (see server logs)."


class AuditService:
    def __init__(
        self,
        *,
        repository: AuditRepository,
        llm: LLMClient,
        github: GitHubClient,
        settings: Settings,
    ) -> None:
        self.repo = repository
        self.llm = llm
        self.github = github
        self.settings = settings
        self._semaphore = asyncio.Semaphore(settings.max_concurrent_audits)
        self._limits = ScanLimits(
            max_file_bytes=settings.max_file_bytes,
            max_files=settings.max_files,
            max_total_bytes=settings.max_total_uncompressed_bytes,
        )

    # ------------------------------------------------------------------------------------------
    # Submission (request path)
    # ------------------------------------------------------------------------------------------
    async def _create_run(self, meta: RepoMetadata, git_ref: str | None) -> dict[str, Any]:
        repo_row = await self.repo.upsert_repository(meta.as_row())
        return await self.repo.create_audit_run(
            {
                "repository_id": repo_row["id"],
                "git_ref": git_ref,
                "llm_provider": self.llm.provider,
                "llm_model": self.llm.model,
            }
        )

    async def submit_github(self, request: GitHubAuditRequest) -> tuple[dict[str, Any], AuditJob]:
        target = parse_github_url(request.repo_url)
        meta = await self.github.fetch_metadata(target)
        ref = request.ref or target.ref or meta.default_branch or "HEAD"
        run = await self._create_run(meta, ref)
        job = AuditJob(
            audit_id=str(run["id"]),
            repository_name=meta.name,
            repository_url=meta.url,
            git_ref=ref,
            load_archive=lambda: self.github.download_archive(target, ref),
        )
        return run, job

    async def submit_upload(self, filename: str, data: bytes) -> tuple[dict[str, Any], AuditJob]:
        if not zipfile.is_zipfile(io.BytesIO(data)):
            raise IngestError("The uploaded file is not a valid ZIP archive.", http_status=422)
        digest = hashlib.sha256(data).hexdigest()
        stem = re.sub(r"\.zip$", "", filename.rsplit("/", 1)[-1], flags=re.I)
        name = re.sub(r"[^a-z0-9._-]+", "-", stem.lower()).strip("-") or "upload"
        meta = RepoMetadata(source_type=SourceType.ZIP, source_key=f"zip:{digest[:40]}", name=name)
        run = await self._create_run(meta, None)

        async def _load() -> bytes:
            return data

        job = AuditJob(
            audit_id=str(run["id"]), repository_name=name, repository_url=None, git_ref=None, load_archive=_load
        )
        return run, job

    # ------------------------------------------------------------------------------------------
    # Execution (background path)
    # ------------------------------------------------------------------------------------------
    async def execute(self, job: AuditJob) -> None:
        async with self._semaphore:
            started = time.perf_counter()
            try:
                await self.repo.mark_processing(job.audit_id)
                await self._run_pipeline(job, started)
                logger.info("Audit %s completed in %.1fs", job.audit_id, time.perf_counter() - started)
            except Exception as exc:  # noqa: BLE001 - must never escape a background task
                logger.exception("Audit %s failed", job.audit_id)
                try:
                    await self.repo.fail_audit(
                        job.audit_id, _public_error(exc), int((time.perf_counter() - started) * 1000)
                    )
                except Exception:  # noqa: BLE001
                    logger.exception("Could not record failure for audit %s", job.audit_id)

    async def _run_pipeline(self, job: AuditJob, started: float) -> None:
        archive = await job.load_archive()
        # Parsing is CPU-bound: run it off the event loop so the API stays responsive.
        scan = await asyncio.to_thread(scan_archive, archive, self._limits)
        del archive

        context = build_context(scan, self.settings.effective_context_budget)
        logger.info(
            "Audit %s: %d files scanned, %d sent to LLM (%d chars), %d static findings",
            job.audit_id, len(scan.files), len(context.included), context.char_count, len(scan.static_findings),
        )

        result, usage = await generate_structured(
            self.llm,
            AuditLLMResult,
            system_prompt=system_prompt(),
            user_prompt=user_prompt(repository=job.repository_name, git_ref=job.git_ref, context=context),
        )

        findings = merge_findings(scan, result)
        report = render_report(
            ReportMeta(
                repository_name=job.repository_name,
                repository_url=job.repository_url,
                git_ref=job.git_ref,
                generated_at=datetime.now(timezone.utc),
                model_label=f"{self.llm.provider}/{self.llm.model}",
            ),
            scan,
            result,
            findings,
        )
        stats = scan.archive.stats
        run_update = {
            "generator": scan.generator,
            "detected_frameworks": scan.frameworks,
            "files_scanned": stats.kept_files,
            "files_skipped": stats.skipped_total,
            "total_bytes": stats.kept_bytes,
            "structure": scan.structure_summary(),
            "architecture_score": result.architecture.score,
            "architecture_summary": result.architecture.summary,
            "database_score": result.database.score,
            "database_summary": result.database.summary,
            "security_score": result.security.score,
            "security_summary": result.security.summary,
            "remediation_effort": result.remediation.level.value,
            "remediation_rationale": result.remediation.rationale,
            "top_priorities": result.remediation.top_priorities,
            "executive_summary": result.executive_summary,
            "report_markdown": report,
            "findings_count": len(findings),
            "critical_count": sum(1 for f in findings if f["severity"] == "critical"),
            "high_count": sum(1 for f in findings if f["severity"] == "high"),
            "prompt_tokens": usage.prompt_tokens,
            "completion_tokens": usage.completion_tokens,
            "duration_ms": int((time.perf_counter() - started) * 1000),
        }
        await self.repo.complete_audit(job.audit_id, run_update, findings)

    # ------------------------------------------------------------------------------------------
    # Housekeeping
    # ------------------------------------------------------------------------------------------
    async def recover_stale_runs(self) -> None:
        """Background tasks die with the process (e.g. free-tier spin-down). Mark orphans as failed."""
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=self.settings.stale_audit_minutes)
        try:
            count = await self.repo.fail_stale_runs(cutoff, "Audit was interrupted (service restarted). Please resubmit.")
            if count:
                logger.warning("Marked %d stale audit run(s) as failed", count)
        except Exception:  # noqa: BLE001 - never block startup on housekeeping
            logger.exception("Stale-run recovery failed")
