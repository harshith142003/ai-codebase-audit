"""Fetch repository metadata and source archives from GitHub."""

from __future__ import annotations

import logging
from dataclasses import dataclass

import httpx

from app.config import Settings
from app.errors import IngestError
from app.models.api import GITHUB_URL_RE
from app.models.enums import SourceType

logger = logging.getLogger(__name__)

API = "https://api.github.com"


@dataclass(frozen=True)
class GitHubTarget:
    owner: str
    repo: str
    ref: str | None = None

    @property
    def full_name(self) -> str:
        return f"{self.owner}/{self.repo}".lower()

    @property
    def canonical_url(self) -> str:
        return f"https://github.com/{self.full_name}"


@dataclass(frozen=True)
class RepoMetadata:
    source_type: SourceType
    source_key: str
    name: str
    owner: str | None = None
    url: str | None = None
    default_branch: str | None = None
    description: str | None = None
    primary_language: str | None = None
    stars: int | None = None

    def as_row(self) -> dict[str, object]:
        return {
            "source_type": self.source_type.value,
            "source_key": self.source_key,
            "name": self.name,
            "owner": self.owner,
            "url": self.url,
            "default_branch": self.default_branch,
            "description": (self.description or "")[:1000] or None,
            "primary_language": self.primary_language,
            "stars": self.stars,
        }


def parse_github_url(url: str) -> GitHubTarget:
    m = GITHUB_URL_RE.match(url.strip())
    if not m:
        raise IngestError("Not a valid GitHub repository URL.", http_status=422)
    return GitHubTarget(owner=m.group("owner"), repo=m.group("repo"), ref=m.group("ref"))


class GitHubClient:
    def __init__(self, settings: Settings, http: httpx.AsyncClient) -> None:
        self._http = http
        self._max_bytes = settings.max_archive_bytes
        self._headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        self._authenticated = settings.github_token is not None
        if settings.github_token:
            self._headers["Authorization"] = f"Bearer {settings.github_token.get_secret_value()}"

    @staticmethod
    def _is_rate_limited(response: httpx.Response) -> bool:
        return response.status_code in (403, 429) and response.headers.get("x-ratelimit-remaining") == "0"

    def _archive_url(self, target: GitHubTarget, ref: str) -> str:
        if self._authenticated:  # API zipball: works for private repos the token can read
            return f"{API}/repos/{target.owner}/{target.repo}/zipball/{ref}"
        # Public archive endpoint: not subject to the REST API's anonymous rate limit.
        return f"https://github.com/{target.owner}/{target.repo}/archive/{ref}.zip"

    def _raise_for(self, response: httpx.Response, target: GitHubTarget, what: str) -> None:
        if response.status_code == 404:
            raise IngestError(f"GitHub {what} not found for {target.full_name} (is the repository public?).", http_status=404)
        if self._is_rate_limited(response):
            raise IngestError("GitHub API rate limit reached; set GITHUB_TOKEN to raise it.", http_status=429)
        if response.status_code >= 400:
            raise IngestError(f"GitHub returned HTTP {response.status_code} for {what}.", http_status=502)

    async def fetch_metadata(self, target: GitHubTarget) -> RepoMetadata:
        try:
            response = await self._http.get(
                f"{API}/repos/{target.owner}/{target.repo}", headers=self._headers, timeout=15
            )
        except httpx.HTTPError as exc:
            raise IngestError(f"Could not reach GitHub: {exc}", http_status=502) from exc
        if self._is_rate_limited(response) and not self._authenticated:
            # Metadata is nice-to-have. Free-tier hosts share egress IPs, so the 60 req/h anonymous
            # API quota is easily exhausted by others: degrade gracefully instead of failing the audit.
            logger.warning("GitHub API rate-limited; continuing without metadata for %s", target.full_name)
            return RepoMetadata(
                source_type=SourceType.GITHUB,
                source_key=target.canonical_url,
                name=target.full_name,
                owner=target.owner,
                url=target.canonical_url,
            )
        self._raise_for(response, target, "repository")
        data = response.json()
        return RepoMetadata(
            source_type=SourceType.GITHUB,
            source_key=target.canonical_url,
            name=str(data.get("full_name") or target.full_name).lower(),
            owner=(data.get("owner") or {}).get("login"),
            url=data.get("html_url") or target.canonical_url,
            default_branch=data.get("default_branch"),
            description=data.get("description"),
            primary_language=data.get("language"),
            stars=data.get("stargazers_count"),
        )

    async def download_archive(self, target: GitHubTarget, ref: str) -> bytes:
        """Stream the zipball with a hard size cap (never buffers more than the limit)."""
        url = self._archive_url(target, ref)
        buffer = bytearray()
        try:
            async with self._http.stream(
                "GET", url, headers=self._headers, follow_redirects=True, timeout=httpx.Timeout(30, read=120)
            ) as response:
                if response.status_code >= 400:
                    await response.aread()
                    self._raise_for(response, target, f"ref '{ref}'")
                async for chunk in response.aiter_bytes():
                    buffer.extend(chunk)
                    if len(buffer) > self._max_bytes:
                        raise IngestError(
                            f"Repository archive exceeds the {self._max_bytes // (1024 * 1024)} MB limit.",
                            http_status=413,
                        )
        except httpx.HTTPError as exc:
            raise IngestError(f"Failed to download repository archive: {exc}", http_status=502) from exc
        logger.info("Downloaded %s@%s (%.1f MB)", target.full_name, ref, len(buffer) / 1_048_576)
        return bytes(buffer)
