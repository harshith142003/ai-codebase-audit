"""Render the client-facing Markdown audit report (ready to paste into a proposal)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from app.analysis.scanner import ScanResult
from app.models.enums import FindingCategory
from app.models.llm import AuditLLMResult

_CATEGORY_TITLES = {
    FindingCategory.SECURITY.value: "Security",
    FindingCategory.DATABASE.value: "Database Design & Data Access",
    FindingCategory.ARCHITECTURE.value: "Architecture & Maintainability",
}
_CATEGORY_ORDER = [FindingCategory.SECURITY.value, FindingCategory.DATABASE.value, FindingCategory.ARCHITECTURE.value]
_EFFORT_MEANING = {
    "low": "hours to roughly one week of focused work",
    "medium": "roughly one to four weeks of focused work",
    "high": "more than a month, or a partial rebuild",
}


@dataclass(frozen=True)
class ReportMeta:
    repository_name: str
    repository_url: str | None
    git_ref: str | None
    generated_at: datetime
    model_label: str


def _cell(text: str | None, limit: int = 140) -> str:
    text = (text or "—").replace("|", "\\|").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _rating(score: int) -> str:
    if score >= 8:
        return "Strong"
    if score >= 6:
        return "Adequate"
    if score >= 4:
        return "Needs work"
    return "Critical gaps"


def render_report(meta: ReportMeta, scan: ScanResult, result: AuditLLMResult, findings: list[dict[str, Any]]) -> str:
    out: list[str] = []
    w = out.append

    title = f"[{meta.repository_name}]({meta.repository_url})" if meta.repository_url else f"`{meta.repository_name}`"
    w(f"# Codebase Audit: {meta.repository_name}\n")
    w(f"**Repository:** {title}  ")
    if meta.git_ref:
        w(f"**Revision:** `{meta.git_ref}`  ")
    w(f"**Audit date:** {meta.generated_at:%d %B %Y}  ")
    if scan.generator:
        w(f"**Built with:** {scan.generator}  ")
    if scan.frameworks:
        w(f"**Detected stack:** {', '.join(scan.frameworks)}")
    w("")

    w("## Executive Summary\n")
    w(result.executive_summary.strip() + "\n")

    w("## Scorecard\n")
    w("| Area | Score | Rating | Assessment |")
    w("|---|:---:|---|---|")
    for label, crit in (
        ("Architecture & Maintainability", result.architecture),
        ("Database Design & Data Access", result.database),
        ("Security", result.security),
    ):
        w(f"| {label} | **{crit.score}/10** | {_rating(crit.score)} | {_cell(crit.summary, 400)} |")
    w("")

    level = result.remediation.level.value
    w(f"## Remediation Estimate: **{level.capitalize()}**\n")
    w(f"*{level.capitalize()} = {_EFFORT_MEANING[level]}.*\n")
    w(result.remediation.rationale.strip() + "\n")
    if result.remediation.top_priorities:
        w("**Recommended order of work:**\n")
        for i, p in enumerate(result.remediation.top_priorities, 1):
            w(f"{i}. {p}")
        w("")

    counts = {s: sum(1 for f in findings if f["severity"] == s) for s in ("critical", "high", "medium", "low", "info")}
    w("## Findings Overview\n")
    w(" · ".join(f"**{n}** {s}" for s, n in counts.items() if n) + "\n")
    w("| # | Severity | Area | Finding | Location | Effort |")
    w("|---|---|---|---|---|---|")
    for i, f in enumerate(findings, 1):
        loc = f"`{_cell(f.get('file_path'), 60)}`" if f.get("file_path") else "—"
        w(
            f"| {i} | {f['severity'].upper()} | {_CATEGORY_TITLES[f['category']].split(' ')[0]} | "
            f"{_cell(f['title'])} | {loc} | {(f.get('effort') or '—').capitalize()} |"
        )
    w("")

    w("## Detailed Findings\n")
    index = {id(f): i for i, f in enumerate(findings, 1)}
    for cat in _CATEGORY_ORDER:
        group = [f for f in findings if f["category"] == cat]
        if not group:
            continue
        w(f"### {_CATEGORY_TITLES[cat]}\n")
        for f in group:
            origin = "automated check" if f["source"] == "static" else "engineering review"
            w(f"#### {index[id(f)]}. {f['title']}\n")
            meta_line = f"**Severity:** {f['severity'].capitalize()} · **Effort:** {(f.get('effort') or 'n/a').capitalize()}"
            if f.get("file_path"):
                meta_line += f" · **Location:** `{f['file_path']}`"
            w(meta_line + f" · *Source: {origin}*\n")
            w(f["description"].strip() + "\n")
            if f.get("recommendation"):
                w(f"**Recommendation:** {f['recommendation'].strip()}\n")

    stats = scan.archive.stats
    db = scan.database
    w("## Codebase Snapshot\n")
    w(f"- **Files analysed:** {stats.kept_files} source files "
      f"({stats.skipped_total} skipped: build artifacts, dependencies, binaries, lockfiles)")
    w(f"- **Automated tests:** {len(scan.test_files)} test files")
    if scan.routes:
        shown = ", ".join(f"`{r.method} {r.path}`" for r in scan.routes[:12])
        more = f" and {len(scan.routes) - 12} more" if len(scan.routes) > 12 else ""
        w(f"- **Server/API routes ({len(scan.routes)}):** {shown}{more}")
    if db.tables:
        w(f"- **Database tables in migrations ({len(db.tables)}):** {', '.join(f'`{t}`' for t in list(db.tables)[:20])}")
        w(f"- **Explicit indexes:** {len(db.indexes)} · **Tables without RLS:** {len(db.tables_without_rls())} · "
          f"**Unindexed foreign keys:** {len(db.unindexed_foreign_keys())}")
    elif db.typed_tables:
        w(f"- **Tables (from generated types):** {', '.join(f'`{t}`' for t in db.typed_tables[:20])}")
    if scan.largest_files:
        w("- **Largest source files:** " + ", ".join(f"`{p}` ({n} lines)" for p, n in scan.largest_files[:5]))
    w("")

    w("## Methodology\n")
    w(
        "The repository was ingested with build artifacts, dependencies and binaries excluded. Deterministic checks "
        "(dependency and route extraction, SQL schema analysis for indexes and Row Level Security, secret detection) "
        f"ran first; their results and the most relevant source files were then reviewed by `{meta.model_label}`. "
        "Secrets were redacted before any code left our infrastructure. Findings marked *automated check* are "
        "reproducible facts; findings marked *engineering review* reflect judgement and should be confirmed during "
        "discovery."
    )
    return "\n".join(out) + "\n"
