> **Sample output** generated from the test fixture (`tests/fixtures.py`) with a scripted LLM. The *automated check* findings are genuine scanner output; the LLM-written prose is placeholder text. Replace this file with a report from your live deployment.

# Codebase Audit: acme/shop-app

**Repository:** [acme/shop-app](https://github.com/acme/shop-app)  
**Revision:** `main`  
**Audit date:** 08 October 2026  
**Built with:** Lovable  
**Detected stack:** React, Vite, Supabase, TanStack Query, React Router, Tailwind CSS, Zod, Radix UI / shadcn

## Executive Summary

The application works as a prototype but exposes privileged credentials in the browser bundle and leaves two tables without Row Level Security. Data access is spread across UI components.

## Scorecard

| Area | Score | Rating | Assessment |
|---|:---:|---|---|
| Architecture & Maintainability | **5/10** | Needs work | UI components query the database directly; little separation. |
| Database Design & Data Access | **4/10** | Needs work | Missing RLS and an unindexed foreign key on orders.product_id. |
| Security | **2/10** | Critical gaps | A service_role key and a Stripe live key are committed to source. |

## Remediation Estimate: **Medium**

*Medium = roughly one to four weeks of focused work.*

Secrets rotation and RLS are quick; extracting a data layer is a few weeks of work.

**Recommended order of work:**

1. Rotate keys
2. Enable RLS
3. Add FK indexes
4. Create data layer
5. Add tests

## Findings Overview

**3** critical · **1** high · **3** medium · **2** low · **1** info

| # | Severity | Area | Finding | Location | Effort |
|---|---|---|---|---|---|
| 1 | CRITICAL | Security | Hardcoded secret: Stripe live secret key | `src/lib/payments.ts` | Low |
| 2 | CRITICAL | Security | Hardcoded secret: Supabase service_role key (bypasses RLS) | `src/pages/Admin.tsx` | Low |
| 3 | CRITICAL | Security | Admin page authorises with a service_role key in the browser | `src/pages/Admin.tsx` | Low |
| 4 | HIGH | Security | Row Level Security not enabled on 2 public table(s) | `supabase/migrations/20240101000000_init.sql` | Medium |
| 5 | MEDIUM | Database | 2 foreign-key column(s) without a supporting index | `supabase/migrations/20240101000000_init.sql` | Low |
| 6 | MEDIUM | Security | Raw HTML rendering without a sanitiser | `src/pages/Admin.tsx` | Low |
| 7 | MEDIUM | Database | Orders listing is unbounded | — | Low |
| 8 | LOW | Security | Committed .env file (client-side variables only) | `.env` | Low |
| 9 | LOW | Architecture | No shared error handling | — | Medium |
| 10 | INFO | Security | Supabase public (anon/publishable) key embedded in client code | `.env` | Low |

## Detailed Findings

### Security

#### 1. Hardcoded secret: Stripe live secret key

**Severity:** Critical · **Effort:** Low · **Location:** `src/lib/payments.ts` · *Source: automated check*

A credential matching `stripe_live_secret` is committed to source control at `src/lib/payments.ts:1` (value preview: sk_liv…[36 chars]). Anyone with repository or bundle access can use it.

**Recommendation:** Rotate the credential immediately, move it to server-side environment variables / a secrets manager, and purge it from git history (e.g. git filter-repo).

#### 2. Hardcoded secret: Supabase service_role key (bypasses RLS)

**Severity:** Critical · **Effort:** Low · **Location:** `src/pages/Admin.tsx` · *Source: automated check*

A credential matching `supabase_service_role_key` is committed to source control at `src/pages/Admin.tsx:4` (value preview: eyJhbG…[179 chars]). Anyone with repository or bundle access can use it.

**Recommendation:** Rotate the credential immediately, move it to server-side environment variables / a secrets manager, and purge it from git history (e.g. git filter-repo).

#### 3. Admin page authorises with a service_role key in the browser

**Severity:** Critical · **Effort:** Low · **Location:** `src/pages/Admin.tsx` · *Source: engineering review*

The Admin page builds a Supabase client with a service_role key, bypassing RLS for anyone.

**Recommendation:** Move admin operations to an edge function that checks the caller's role.

#### 4. Row Level Security not enabled on 2 public table(s)

**Severity:** High · **Effort:** Medium · **Location:** `supabase/migrations/20240101000000_init.sql` · *Source: automated check*

No `ENABLE ROW LEVEL SECURITY` statement was found for `orders`, `products`. With Supabase, the anon key is shipped to the browser, so these tables are exposed through the auto-generated REST API.

**Recommendation:** Enable RLS on every public table and add least-privilege policies (e.g. `auth.uid() = user_id`).

#### 6. Raw HTML rendering without a sanitiser

**Severity:** Medium · **Effort:** Low · **Location:** `src/pages/Admin.tsx` · *Source: automated check*

`dangerouslySetInnerHTML` is used in `src/pages/Admin.tsx` and no HTML sanitiser (e.g. DOMPurify) is a dependency. If any of that HTML is user-controlled this is a stored XSS vector.

**Recommendation:** Sanitise with DOMPurify or render Markdown through a safe renderer.

#### 8. Committed .env file (client-side variables only)

**Severity:** Low · **Effort:** Low · **Location:** `.env` · *Source: automated check*

`.env` is tracked in git. It currently holds only browser-exposed variables, but the pattern makes it easy for a real secret to be committed later.

**Recommendation:** Untrack the file, add it to .gitignore and provide a `.env.example` instead.

#### 10. Supabase public (anon/publishable) key embedded in client code

**Severity:** Info · **Effort:** Low · **Location:** `.env` · *Source: automated check*

Found in `.env:2`, `src/integrations/supabase/client.ts:5`. This key is public by design, which means every table is protected only by Row Level Security policies — any table without correct RLS is readable and writable by anyone holding this key.

**Recommendation:** Keep the key in environment config and verify RLS + policies on every table.

### Database Design & Data Access

#### 5. 2 foreign-key column(s) without a supporting index

**Severity:** Medium · **Effort:** Low · **Location:** `supabase/migrations/20240101000000_init.sql` · *Source: automated check*

Postgres does not index foreign keys automatically. Unindexed: `orders.product_id → products`, `products.vendor_id → vendors`. Joins, lookups by parent and ON DELETE cascades will degrade to sequential scans as data grows.

**Recommendation:** Add a btree index per FK column (or a composite index led by it) in a new migration.

#### 7. Orders listing is unbounded

**Severity:** Medium · **Effort:** Low · *Source: engineering review*

select('*') on orders without pagination will degrade as the table grows.

**Recommendation:** Paginate with range() and select only needed columns.

### Architecture & Maintainability

#### 9. No shared error handling

**Severity:** Low · **Effort:** Medium · *Source: engineering review*

Supabase errors are ignored throughout the UI, hiding failures from users.

**Recommendation:** Wrap queries in a hook that surfaces errors via toasts.

## Codebase Snapshot

- **Files analysed:** 15 source files (4 skipped: build artifacts, dependencies, binaries, lockfiles)
- **Automated tests:** 0 test files
- **Server/API routes (7):** `GET /api/users`, `POST /api/users`, `ANY /functions/v1/send-email`, `GET /health`, `POST /items`, `GET /legacy`, `PUT /legacy`
- **Database tables in migrations (3):** `profiles`, `orders`, `products`
- **Explicit indexes:** 2 · **Tables without RLS:** 2 · **Unindexed foreign keys:** 2
- **Largest source files:** `backend/main.py` (16 lines), `src/pages/Admin.tsx` (15 lines), `src/integrations/supabase/types.ts` (14 lines), `src/integrations/supabase/client.ts` (8 lines), `src/lib/payments.ts` (5 lines)

## Methodology

The repository was ingested with build artifacts, dependencies and binaries excluded. Deterministic checks (dependency and route extraction, SQL schema analysis for indexes and Row Level Security, secret detection) ran first; their results and the most relevant source files were then reviewed by `fake/fake-model`. Secrets were redacted before any code left our infrastructure. Findings marked *automated check* are reproducible facts; findings marked *engineering review* reflect judgement and should be confirmed during discovery.
