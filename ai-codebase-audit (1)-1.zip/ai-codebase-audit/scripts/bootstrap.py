"""One-command setup. From the repo root:   python scripts/bootstrap.py

Automates everything that can run on your machine (standard library only, works on
Windows / macOS / Linux, safe to re-run):

  1. creates .venv and installs dependencies
  2. runs the test-suite
  3. asks for your keys and writes .env (git-ignored); generates an API_KEY for you
  4. verifies the LLM key and the Supabase migration with live calls (scripts/preflight.py)
  5. commits the code; if the GitHub CLI (`gh`) is installed and logged in, creates a
     public repo and pushes it
  6. prints your one-click "Deploy to Render" link and the values to paste there
"""

from __future__ import annotations

import getpass
import os
import secrets
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
os.chdir(ROOT)
IS_WINDOWS = os.name == "nt"
VENV_PY = ROOT / ".venv" / ("Scripts/python.exe" if IS_WINDOWS else "bin/python")
ENV_PATH = ROOT / ".env"


def step(n: int, title: str) -> None:
    print(f"\n=== Step {n}/6: {title} ===")


def run(cmd: list[str], check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, check=check, text=True, capture_output=capture)


def ask(prompt: str, default: str = "", secret: bool = False) -> str:
    suffix = f" [{default}]" if default and not secret else ""
    reader = getpass.getpass if (secret and sys.stdin.isatty()) else input
    try:
        value = reader(f"  {prompt}{suffix}: ").strip()
    except EOFError:  # non-interactive run (piped input exhausted): fall back to the default
        print()
        value = ""
    return value or default


def yes(prompt: str, default: bool = True) -> bool:
    answer = ask(f"{prompt} ({'Y/n' if default else 'y/N'})").lower()
    return default if not answer else answer.startswith("y")


def read_env() -> dict[str, str]:
    values: dict[str, str] = {}
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
            if "=" in line and not line.lstrip().startswith("#"):
                key, _, val = line.partition("=")
                values[key.strip()] = val.split("#", 1)[0].strip()
    return values


def write_env(values: dict[str, str]) -> None:
    lines = ["# Written by scripts/bootstrap.py. Git-ignored: never commit this file."]
    lines += [f"{k}={v}" for k, v in values.items()]
    ENV_PATH.write_text("\n".join(lines) + "\n", encoding="utf-8")


def setup_venv() -> None:
    step(1, "Python environment")
    if sys.version_info < (3, 11):
        sys.exit(f"  Python 3.11+ is required (you have {sys.version.split()[0]}). Install 3.12 from python.org.")
    if not VENV_PY.exists():
        print("  creating .venv ...")
        run([sys.executable, "-m", "venv", ".venv"])
    print("  installing dependencies (about a minute the first time) ...")
    run([str(VENV_PY), "-m", "pip", "install", "-q", "--disable-pip-version-check", "-r", "requirements-dev.txt"])
    print("  [OK] dependencies installed")


def run_tests() -> None:
    step(2, "Test-suite")
    result = run([str(VENV_PY), "-m", "pytest", "-q", "-p", "no:warnings"], check=False, capture=True)
    print("  " + (result.stdout.strip().splitlines() or ["(no output)"])[-1])
    if result.returncode != 0:
        print(result.stdout[-3000:])
        sys.exit("  Tests failed. Paste the output above to get help.")


def configure_env() -> dict[str, str]:
    step(3, "Configuration (.env)")
    current = read_env()
    if current.get("LLM_API_KEY") and not yes("Existing .env found. Edit it?", default=False):
        return current

    print("  Get a free Gemini key at https://aistudio.google.com/apikey (or use a Groq key with provider 'groq').")
    provider = ask("LLM provider (gemini/groq/deepseek/openrouter)", current.get("LLM_PROVIDER", "gemini"))
    llm_key = ask("LLM API key", secret=True) or current.get("LLM_API_KEY", "")
    values = {
        "APP_ENV": "development",
        "LOG_LEVEL": "INFO",
        "LLM_PROVIDER": provider,
        "LLM_API_KEY": llm_key,
    }
    if provider == "openrouter":
        values["LLM_MODEL"] = ask("OpenRouter model id (e.g. a ':free' model)", current.get("LLM_MODEL", ""))

    print("\n  Supabase: create a project, open SQL Editor, paste supabase/migrations/*.sql and click Run.")
    print("  Then copy Project URL + service_role/secret key from Project Settings -> API keys.")
    url = ask("Supabase project URL (leave empty to use in-memory DB for now)", current.get("SUPABASE_URL", ""))
    if url:
        values["DB_BACKEND"] = "supabase"
        values["SUPABASE_URL"] = url.rstrip("/")
        values["SUPABASE_SERVICE_ROLE_KEY"] = (
            ask("Supabase service_role / secret key", secret=True) or current.get("SUPABASE_SERVICE_ROLE_KEY", "")
        )
    else:
        values["DB_BACKEND"] = "memory"

    values["API_KEY"] = current.get("API_KEY") or secrets.token_urlsafe(24)
    gh_token = ask("GitHub token (optional, press Enter to skip)", secret=True) or current.get("GITHUB_TOKEN", "")
    if gh_token:
        values["GITHUB_TOKEN"] = gh_token
    write_env(values)
    print("  [OK] .env written (git-ignored)")
    return values


def preflight() -> bool:
    step(4, "Live checks (LLM + Supabase)")
    result = run([str(VENV_PY), "scripts/preflight.py"], check=False)
    return result.returncode == 0


def github_publish() -> str | None:
    step(5, "GitHub")
    if not shutil.which("git"):
        print("  git is not installed: install it from https://git-scm.com, then re-run.")
        return None

    if not (ROOT / ".git").exists():
        run(["git", "init", "-q", "-b", "main"])
    if run(["git", "config", "user.email"], check=False, capture=True).returncode != 0:
        print("  git needs your identity once:")
        run(["git", "config", "user.name", ask("Your name")])
        run(["git", "config", "user.email", ask("Your email")])

    existing = run(["git", "remote", "get-url", "origin"], check=False, capture=True)
    repo_url = existing.stdout.strip().removesuffix(".git") if existing.returncode == 0 else None

    gh_ready = bool(shutil.which("gh")) and run(["gh", "auth", "status"], check=False, capture=True).returncode == 0
    if not repo_url and gh_ready:
        login = run(["gh", "api", "user", "-q", ".login"], capture=True).stdout.strip()
        name = ask("New public repo name", "ai-codebase-audit")
        repo_url = f"https://github.com/{login}/{name}"
        _patch_readme(repo_url)
        _commit("AI codebase audit engine")
        run(["gh", "repo", "create", name, "--public", "--source", ".", "--remote", "origin", "--push"])
        print(f"  [OK] pushed to {repo_url}")
        return repo_url

    if repo_url:
        _patch_readme(repo_url)
        _commit("Update")
        if run(["git", "push", "-u", "origin", "HEAD"], check=False).returncode == 0:
            print(f"  [OK] pushed to {repo_url}")
        else:
            print("  [FAIL] push failed: run `git push -u origin main` yourself (sign in when asked),")
            print("         then use the Render link below. Render can only deploy code that is on GitHub.")
        return repo_url

    _commit("AI codebase audit engine")
    print("  GitHub CLI not available, so do this once by hand:")
    print("   1. Create an EMPTY public repo at https://github.com/new (no README).")
    print("   2. git remote add origin https://github.com/<you>/<repo>.git")
    print("   3. git push -u origin main")
    print("   4. Re-run this script; it will print your Render link.")
    print("  (Or install https://cli.github.com, run `gh auth login`, and re-run to automate this.)")
    return None


def _patch_readme(repo_url: str) -> None:
    readme = ROOT / "README.md"
    text = readme.read_text(encoding="utf-8")
    patched = text.replace("<github-repo-url>", repo_url).replace("git clone <this-repo>", f"git clone {repo_url}")
    if patched != text:
        readme.write_text(patched, encoding="utf-8")


def _commit(message: str) -> None:
    run(["git", "add", "-A"])
    staged = run(["git", "diff", "--cached", "--name-only"], capture=True).stdout.split()
    if ".env" in staged:  # belt and braces: .gitignore should already prevent this
        run(["git", "reset", "-q", ".env"])
        sys.exit("  Refusing to commit .env. Check your .gitignore.")
    if staged:
        run(["git", "commit", "-q", "-m", message])


def render_instructions(repo_url: str | None, env: dict[str, str]) -> None:
    step(6, "Deploy on Render")
    if not repo_url:
        print("  Push to GitHub first (step 5), then re-run for your one-click link.")
        return
    if env.get("DB_BACKEND") != "supabase":
        print("  [WARN] Your .env uses the in-memory DB, but render.yaml deploys with DB_BACKEND=supabase.")
        print("         Set up Supabase first (re-run this script and enter the URL/key), or the deploy will fail.")
    print(f"  1. Open: https://render.com/deploy?repo={repo_url}")
    print("  2. Sign in with GitHub, approve access to the repo, and fill in these values when prompted:")
    for key in ("SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY", "LLM_API_KEY", "API_KEY", "GITHUB_TOKEN"):
        if env.get(key):
            shown = env[key] if key in ("SUPABASE_URL", "API_KEY") else "(same value as in your .env)"
            print(f"       {key} = {shown}")
    print("  3. When it shows 'Live': open https://<service>.onrender.com/health?deep=true")
    print(f"  4. Demo:  BASE_URL=https://<service>.onrender.com API_KEY={env.get('API_KEY', '')} ./scripts/demo.sh")
    print("     Or use /docs: click 'Authorize' and paste the API_KEY.")


def main() -> None:
    print("AI Codebase Audit Engine: bootstrap")
    setup_venv()
    run_tests()
    env = configure_env()
    if not preflight() and not yes("Live checks failed. Continue to GitHub anyway?", default=False):
        sys.exit("  Fix the .env values (re-run this script) and try again.")
    repo_url = github_publish()
    render_instructions(repo_url, env)
    print("\nDone. Remaining: record the video (see SUBMISSION_GUIDE.md) and submit the links.")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as exc:
        sys.exit(f"\nCommand failed: {' '.join(map(str, exc.cmd))}")
    except KeyboardInterrupt:
        sys.exit("\nAborted.")
