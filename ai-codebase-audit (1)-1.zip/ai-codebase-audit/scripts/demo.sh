#!/usr/bin/env bash
# End-to-end demo against a running instance.
#   BASE_URL=https://your-service.onrender.com API_KEY=... ./scripts/demo.sh https://github.com/owner/repo
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8000}"
REPO_URL="${1:-https://github.com/senarzuniga/adaptive-sales-engine}"
AUTH=()
[[ -n "${API_KEY:-}" ]] && AUTH=(-H "X-API-Key: ${API_KEY}")

echo "== Health"
curl -s "${BASE_URL}/health?deep=true"; echo

echo "== Submit audit for ${REPO_URL}"
RESPONSE=$(curl -s -X POST "${BASE_URL}/audits" ${AUTH[@]+"${AUTH[@]}"} -H "Content-Type: application/json" \
  -d "{\"repo_url\": \"${REPO_URL}\"}")
echo "${RESPONSE}"
AUDIT_ID=$(echo "${RESPONSE}" | python3 -c "import sys, json; print(json.load(sys.stdin)['audit_id'])")

echo "== Polling ${AUDIT_ID}"
for _ in $(seq 1 60); do
  STATUS=$(curl -s "${BASE_URL}/audits/${AUDIT_ID}" ${AUTH[@]+"${AUTH[@]}"} | python3 -c "import sys, json; print(json.load(sys.stdin)['status'])")
  echo "   status=${STATUS}"
  [[ "${STATUS}" == "completed" || "${STATUS}" == "failed" ]] && break
  sleep 5
done

echo "== Markdown report"
curl -s "${BASE_URL}/audits/${AUDIT_ID}/report" ${AUTH[@]+"${AUTH[@]}"}
