"""Live configuration check. Run from the repo root:  python scripts/preflight.py

Verifies, with real calls, that:
  1. the LLM key + model in .env work and return JSON;
  2. (if DB_BACKEND=supabase) Supabase is reachable, the key is valid, and the migration has been applied.
Exit code 0 = ready to deploy.
"""

from __future__ import annotations

import asyncio
import os
import sys
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

import httpx  # noqa: E402
from pydantic import ValidationError  # noqa: E402

from app.config import Settings  # noqa: E402
from app.errors import AuditError  # noqa: E402
from app.llm.client import OpenAICompatibleClient  # noqa: E402
from app.llm.structured import extract_json  # noqa: E402


def ok(msg: str) -> None:
    print(f"  [OK]   {msg}")


def fail(msg: str) -> None:
    print(f"  [FAIL] {msg}")


async def check_llm(settings: Settings) -> bool:
    print(f"\nLLM: {settings.llm_provider} / {settings.effective_llm_model}")
    async with httpx.AsyncClient() as http:
        client = OpenAICompatibleClient(
            http=http,
            provider=settings.llm_provider,
            base_url=settings.effective_llm_base_url,
            api_key=settings.llm_api_key.get_secret_value(),
            model=settings.effective_llm_model,
            max_output_tokens=1024,
            reasoning_effort=settings.effective_reasoning_effort,
            timeout_seconds=60,
            max_retries=2,
        )
        try:
            resp = await client.chat(
                [
                    {"role": "system", "content": "Reply with a single JSON object and nothing else."},
                    {"role": "user", "content": 'Return exactly: {"ok": true}'},
                ]
            )
            data = extract_json(resp.content)
        except AuditError as exc:
            fail(exc.message)
            return False
        except ValueError:
            fail("The model replied, but not with JSON. Try another LLM_MODEL.")
            return False
    if data.get("ok") is True:
        ok(f"key works, JSON mode works ({resp.usage.prompt_tokens}+{resp.usage.completion_tokens} tokens)")
        return True
    fail(f"unexpected reply: {data}")
    return False


async def check_supabase(settings: Settings) -> bool:
    from app.db.supabase_repo import SupabaseAuditRepository

    print(f"\nSupabase: {settings.supabase_url}")
    try:
        repo = SupabaseAuditRepository(settings.supabase_url or "", settings.supabase_service_role_key.get_secret_value())
    except Exception as exc:  # noqa: BLE001
        fail(f"could not create client: {exc}")
        return False

    try:
        await repo.ping()
        ok("connected; table `repositories` exists")
    except AuditError as exc:
        msg = exc.message.lower()
        if "repositories" in msg or "pgrst205" in msg or "schema cache" in msg or "does not exist" in msg:
            fail("tables not found -> paste supabase/migrations/*.sql into the Supabase SQL Editor and click Run")
        elif "invalid api key" in msg or "401" in msg or "jwt" in msg:
            fail("Supabase rejected the key -> use the service_role / secret key, not the anon/publishable key")
        else:
            fail(exc.message)
        return False

    try:  # Calling the RPC for a random id must fail *inside* the function -> proves it exists.
        await repo.complete_audit(str(uuid.uuid4()), {}, [])
        fail("complete_audit_run accepted a non-existent run (unexpected)")
        return False
    except AuditError as exc:
        if "not in processing state" in exc.message:
            ok("function complete_audit_run exists (migration fully applied)")
            return True
        fail(f"function complete_audit_run missing or not callable -> re-run the migration ({exc.message[:160]})")
        return False


async def main() -> int:
    print("Preflight check (reads .env)")
    try:
        settings = Settings()  # type: ignore[call-arg]
    except ValidationError as exc:
        fail("configuration invalid:")
        for err in exc.errors():
            print(f"         - {'.'.join(map(str, err['loc'])) or 'settings'}: {err['msg']}")
        return 1

    results = [await check_llm(settings)]
    if settings.db_backend == "supabase":
        results.append(await check_supabase(settings))
    else:
        print("\nSupabase: skipped (DB_BACKEND=memory)")

    print("\nREADY TO DEPLOY" if all(results) else "\nFix the [FAIL] items above, then re-run.")
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
