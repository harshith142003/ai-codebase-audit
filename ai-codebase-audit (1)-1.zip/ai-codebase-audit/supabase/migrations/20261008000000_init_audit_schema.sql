-- =============================================================================================
-- AI Codebase Audit Engine — initial schema
--
-- Run in the Supabase SQL editor, or with the CLI: `supabase db push`.
-- The script is idempotent: it is safe to run more than once.
--
-- Tables
--   repositories    one row per audited source (GitHub repo or uploaded ZIP), deduplicated by source_key
--   audit_runs      one row per audit execution (status machine + scores + client-facing report)
--   audit_findings  itemised findings, FK -> audit_runs (ON DELETE CASCADE)
-- =============================================================================================

-- ---------------------------------------------------------------------------------------------
-- Enums: constrain values at the database level (and give severity a natural sort order)
-- ---------------------------------------------------------------------------------------------
do $$ begin
  create type public.audit_status as enum ('queued', 'processing', 'completed', 'failed');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.source_type as enum ('github', 'zip');
exception when duplicate_object then null; end $$;

do $$ begin
  -- Declaration order == sort order, so ORDER BY severity lists critical first.
  create type public.finding_severity as enum ('critical', 'high', 'medium', 'low', 'info');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.finding_category as enum ('architecture', 'database', 'security');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.finding_source as enum ('static', 'llm');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.effort_level as enum ('low', 'medium', 'high');
exception when duplicate_object then null; end $$;

-- ---------------------------------------------------------------------------------------------
-- repositories
-- ---------------------------------------------------------------------------------------------
create table if not exists public.repositories (
  id                uuid primary key default gen_random_uuid(),
  source_type       public.source_type not null,
  -- Canonical identity: 'https://github.com/owner/repo' or 'zip:<sha256 prefix>'.
  source_key        text not null,
  -- Lower-cased 'owner/repo' (GitHub) or archive name (ZIP).
  name              text not null,
  owner             text,
  url               text,
  default_branch    text,
  description       text,
  primary_language  text,
  stars             integer,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  constraint repositories_source_key_key unique (source_key),
  constraint repositories_name_not_blank check (length(btrim(name)) > 0),
  constraint repositories_stars_non_negative check (stars is null or stars >= 0)
);

-- Lookups by repository name (exact match, and prefix search like 'owner/%').
-- text_pattern_ops lets the same btree serve both = and LIKE 'prefix%'.
create index if not exists repositories_name_idx
  on public.repositories (name text_pattern_ops);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists repositories_set_updated_at on public.repositories;
create trigger repositories_set_updated_at
  before update on public.repositories
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------------------------------------
-- audit_runs
-- ---------------------------------------------------------------------------------------------
create table if not exists public.audit_runs (
  id                     uuid primary key default gen_random_uuid(),
  repository_id          uuid not null references public.repositories (id) on delete cascade,
  status                 public.audit_status not null default 'queued',
  git_ref                text,
  llm_provider           text not null,
  llm_model              text not null,
  generator              text,
  detected_frameworks    text[] not null default '{}',
  files_scanned          integer,
  files_skipped          integer,
  total_bytes            bigint,
  structure              jsonb,          -- extracted tree, dependencies, routes, schema analysis
  architecture_score     smallint,
  architecture_summary   text,
  database_score         smallint,
  database_summary       text,
  security_score         smallint,
  security_summary       text,
  remediation_effort     public.effort_level,
  remediation_rationale  text,
  top_priorities         text[] not null default '{}',
  executive_summary      text,
  report_markdown        text,
  findings_count         integer not null default 0,
  critical_count         integer not null default 0,
  high_count             integer not null default 0,
  prompt_tokens          integer,
  completion_tokens      integer,
  duration_ms            integer,
  error_message          text,
  created_at             timestamptz not null default now(),
  started_at             timestamptz,
  completed_at           timestamptz,
  constraint audit_runs_scores_in_range check (
        (architecture_score is null or architecture_score between 1 and 10)
    and (database_score     is null or database_score     between 1 and 10)
    and (security_score     is null or security_score     between 1 and 10)
  ),
  constraint audit_runs_counts_non_negative check (findings_count >= 0 and critical_count >= 0 and high_count >= 0),
  -- State-machine invariants enforced by the database, not just the application:
  constraint audit_runs_completed_has_report check (status <> 'completed' or report_markdown is not null),
  constraint audit_runs_failed_has_error     check (status <> 'failed'    or error_message   is not null)
);

-- "Latest audits", optionally filtered by status (GET /audits?status=completed).
create index if not exists audit_runs_status_created_at_idx
  on public.audit_runs (status, created_at desc);

-- "Latest audits" with no status filter, and created_after / created_before ranges.
create index if not exists audit_runs_created_at_idx
  on public.audit_runs (created_at desc);

-- Postgres does NOT auto-index foreign keys. This composite index covers the FK
-- (joins + ON DELETE CASCADE from repositories) and "audit history for a repo, newest first".
create index if not exists audit_runs_repository_id_created_at_idx
  on public.audit_runs (repository_id, created_at desc);

-- Partial index: only in-flight jobs, so it stays tiny. Serves the stale-job recovery sweep
-- that runs on startup (UPDATE ... WHERE status IN ('queued','processing') AND created_at < ?).
create index if not exists audit_runs_in_flight_idx
  on public.audit_runs (created_at)
  where status in ('queued', 'processing');

-- ---------------------------------------------------------------------------------------------
-- audit_findings
-- ---------------------------------------------------------------------------------------------
create table if not exists public.audit_findings (
  id              uuid primary key default gen_random_uuid(),
  audit_run_id    uuid not null references public.audit_runs (id) on delete cascade,
  category        public.finding_category not null,
  severity        public.finding_severity not null,
  source          public.finding_source not null,
  title           text not null,
  description     text not null,
  recommendation  text,
  file_path       text,
  effort          public.effort_level,
  created_at      timestamptz not null default now(),
  constraint audit_findings_title_length check (length(title) between 1 and 300)
);

-- Covers the FK and "all findings for one audit, most severe first" in a single index.
create index if not exists audit_findings_run_id_severity_idx
  on public.audit_findings (audit_run_id, severity);

-- Cross-audit analytics, e.g. "how many critical security findings this quarter".
create index if not exists audit_findings_category_severity_idx
  on public.audit_findings (category, severity);

-- ---------------------------------------------------------------------------------------------
-- Listing view (used by GET /audits): one row per run with its repository name.
-- security_invoker = true makes the view respect the caller's RLS.
-- ---------------------------------------------------------------------------------------------
create or replace view public.audit_run_summaries
with (security_invoker = true) as
select
  ar.id,
  ar.status,
  ar.git_ref,
  ar.llm_provider,
  ar.llm_model,
  ar.remediation_effort,
  ar.architecture_score,
  ar.database_score,
  ar.security_score,
  ar.findings_count,
  ar.critical_count,
  ar.high_count,
  ar.duration_ms,
  ar.error_message,
  ar.created_at,
  ar.completed_at,
  r.id          as repository_id,
  r.name        as repository_name,
  r.url         as repository_url,
  r.source_type
from public.audit_runs ar
join public.repositories r on r.id = ar.repository_id;

-- ---------------------------------------------------------------------------------------------
-- Atomic completion: findings + final run state in ONE transaction.
-- Called by the backend via PostgREST RPC. If the run is not 'processing', nothing is written.
-- ---------------------------------------------------------------------------------------------
create or replace function public.complete_audit_run(p_audit_id uuid, p_run jsonb, p_findings jsonb)
returns integer
language plpgsql
set search_path = ''
as $$
declare
  v_inserted integer;
begin
  update public.audit_runs set
    status                = 'completed',
    completed_at          = now(),
    generator             = p_run->>'generator',
    detected_frameworks   = coalesce(array(select jsonb_array_elements_text(p_run->'detected_frameworks')), '{}'),
    files_scanned         = (p_run->>'files_scanned')::integer,
    files_skipped         = (p_run->>'files_skipped')::integer,
    total_bytes           = (p_run->>'total_bytes')::bigint,
    structure             = p_run->'structure',
    architecture_score    = (p_run->>'architecture_score')::smallint,
    architecture_summary  = p_run->>'architecture_summary',
    database_score        = (p_run->>'database_score')::smallint,
    database_summary      = p_run->>'database_summary',
    security_score        = (p_run->>'security_score')::smallint,
    security_summary      = p_run->>'security_summary',
    remediation_effort    = (p_run->>'remediation_effort')::public.effort_level,
    remediation_rationale = p_run->>'remediation_rationale',
    top_priorities        = coalesce(array(select jsonb_array_elements_text(p_run->'top_priorities')), '{}'),
    executive_summary     = p_run->>'executive_summary',
    report_markdown       = p_run->>'report_markdown',
    findings_count        = coalesce((p_run->>'findings_count')::integer, 0),
    critical_count        = coalesce((p_run->>'critical_count')::integer, 0),
    high_count            = coalesce((p_run->>'high_count')::integer, 0),
    prompt_tokens         = (p_run->>'prompt_tokens')::integer,
    completion_tokens     = (p_run->>'completion_tokens')::integer,
    duration_ms           = (p_run->>'duration_ms')::integer
  where id = p_audit_id
    and status = 'processing';

  if not found then
    raise exception 'audit run % is not in processing state', p_audit_id using errcode = 'P0001';
  end if;

  insert into public.audit_findings
    (audit_run_id, category, severity, source, title, description, recommendation, file_path, effort)
  select
    p_audit_id,
    f.category::public.finding_category,
    f.severity::public.finding_severity,
    f.source::public.finding_source,
    f.title,
    f.description,
    f.recommendation,
    f.file_path,
    f.effort::public.effort_level
  from jsonb_to_recordset(coalesce(p_findings, '[]'::jsonb)) as f(
    category text, severity text, source text, title text, description text,
    recommendation text, file_path text, effort text
  );

  get diagnostics v_inserted = row_count;
  return v_inserted;
end;
$$;

-- ---------------------------------------------------------------------------------------------
-- Security: RLS on, no policies. Only the backend's service_role key (which bypasses RLS)
-- can read or write; the public anon key sees nothing. The RPC function is likewise
-- restricted to service_role (Supabase exposes public functions to anon by default).
-- ---------------------------------------------------------------------------------------------
alter table public.repositories   enable row level security;
alter table public.audit_runs     enable row level security;
alter table public.audit_findings enable row level security;

revoke all on function public.complete_audit_run(uuid, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.complete_audit_run(uuid, jsonb, jsonb) to service_role;
