import os

# Must be set before `app.main` is imported (it builds the module-level app from env).
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("DB_BACKEND", "memory")
os.environ.setdefault("LLM_API_KEY", "test-key")
os.environ.setdefault("LOG_LEVEL", "WARNING")
