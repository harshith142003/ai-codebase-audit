"""Test fixtures: an in-memory ZIP that looks like a (flawed) Lovable project, plus fakes."""

from __future__ import annotations

import base64
import io
import json
import zipfile

from app.llm.client import LLMResponse, LLMUsage


def make_jwt(payload: dict) -> str:
    enc = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).decode().rstrip("=")  # noqa: E731
    return f"{enc({'alg': 'HS256', 'typ': 'JWT'})}.{enc(payload)}.c2lnbmF0dXJlLXNpZ25hdHVyZQ"


ANON_JWT = make_jwt({"iss": "supabase", "ref": "abcdefghij", "role": "anon", "iat": 1700000000})
SERVICE_JWT = make_jwt({"iss": "supabase", "ref": "abcdefghij", "role": "service_role", "iat": 1700000000})
STRIPE_LIVE = "sk_live_" + "51HxYzAbCdEfGhIjKlMnOpQrStUv"

PACKAGE_JSON = json.dumps(
    {
        "name": "vite_react_shadcn_ts",
        "dependencies": {
            "react": "^18.3.1",
            "react-router-dom": "^6.26.2",
            "@supabase/supabase-js": "^2.50.0",
            "@tanstack/react-query": "^5.56.2",
            "@radix-ui/react-dialog": "^1.1.2",
            "zod": "^3.23.8",
        },
        "devDependencies": {"vite": "^5.4.1", "lovable-tagger": "^1.1.7", "tailwindcss": "^3.4.11"},
        "scripts": {"dev": "vite", "build": "vite build"},
    }
)

MIGRATION_SQL = """
-- Initial schema. Don't forget: it's important to add RLS later!
create table public.profiles (
  id uuid primary key references auth.users on delete cascade,
  username text unique,
  created_at timestamptz default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id),
  product_id uuid,
  note text default 'it''s; fine (really)',
  created_at timestamptz default now(),
  constraint orders_product_fk foreign key (product_id) references products (id)
);

create table "public"."products" ("id" uuid primary key, "name" text not null, "category_id" uuid);

alter table public.products add column if not exists vendor_id uuid references public.vendors(id);

alter table public.profiles enable row level security;
create policy "Users can view own profile" on public.profiles for select using (auth.uid() = id);

create index idx_orders_user on public.orders using btree (user_id);
create index on public.products (lower(name));

create or replace function public.handle_new_user() returns trigger language plpgsql as $$
begin
  insert into public.profiles (id) values (new.id); -- create table fake (x int);
  return new;
end;
$$;
"""

SUPABASE_CLIENT_TS = f"""import {{ createClient }} from '@supabase/supabase-js';
import type {{ Database }} from './types';

const SUPABASE_URL = "https://abcdefghij.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "{ANON_JWT}";

export const supabase = createClient<Database>(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);
"""

SUPABASE_TYPES_TS = """export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: { id: string; username: string | null }
        Insert: { id: string }
      }
      orders: {
        Row: { id: string; user_id: string }
      }
    }
  }
}
"""

ADMIN_PAGE_TSX = f"""import {{ supabase }} from "@/integrations/supabase/client";
import {{ createClient }} from "@supabase/supabase-js";

const SERVICE_KEY = "{SERVICE_JWT}";
const admin = createClient("https://abcdefghij.supabase.co", SERVICE_KEY);

export default function Admin({{ html }}: {{ html: string }}) {{
  const load = async () => {{
    const {{ data }} = await supabase.from('orders').select('*');
    const {{ data: avatar }} = supabase.storage.from('avatars').getPublicUrl('x.png');
    return data;
  }};
  return <div dangerouslySetInnerHTML={{{{ __html: html }}}} />;
}}
"""

PAYMENTS_TS = f"""const stripeSecret = "{STRIPE_LIVE}";
export const apiKey = "your-api-key-here";
export const password = "process.env.DB_PASSWORD";
export async function charge() {{ return stripeSecret; }}
"""

NEXT_ROUTE_TS = """export async function GET() { return Response.json([]) }
export const POST = async (req: Request) => Response.json(await req.json())
"""

FASTAPI_MAIN = '''from fastapi import FastAPI, APIRouter
app = FastAPI()
router = APIRouter()

@app.get("/health")
def health():
    return {"ok": True}

@router.post("/items")
async def create_item():
    return {}

@app.api_route("/legacy", methods=["GET", "PUT"])
def legacy():
    return {}
'''

ENV_FILE = f"VITE_SUPABASE_URL=https://abcdefghij.supabase.co\nVITE_SUPABASE_PUBLISHABLE_KEY={ANON_JWT}\n"

FILES: dict[str, str | bytes] = {
    "package.json": PACKAGE_JSON,
    "package-lock.json": "{}",
    "README.md": "# Welcome to your Lovable project\nhttps://lovable.dev/projects/abc\n",
    ".env": ENV_FILE,
    ".env.example": "VITE_SUPABASE_URL=\nSUPABASE_SERVICE_ROLE_KEY=your-key\n",
    "index.html": "<!doctype html><div id='root'></div>",
    "public/logo.png": b"\x89PNG\r\n\x1a\n\x00\x00\x00binary",
    "node_modules/react/index.js": "module.exports = {}",
    "dist/assets/index-abc123.js": "console.log(1)",
    "src/integrations/supabase/client.ts": SUPABASE_CLIENT_TS,
    "src/integrations/supabase/types.ts": SUPABASE_TYPES_TS,
    "src/pages/Admin.tsx": ADMIN_PAGE_TSX,
    "src/lib/payments.ts": PAYMENTS_TS,
    "src/components/ui/button.tsx": "export const Button = () => null;\n",
    "app/api/users/route.ts": NEXT_ROUTE_TS,
    "supabase/migrations/20240101000000_init.sql": MIGRATION_SQL,
    "supabase/functions/send-email/index.ts": "Deno.serve(async (req) => new Response('ok'))\n",
    "supabase/functions/_shared/cors.ts": "export const cors = {}\n",
    "backend/main.py": FASTAPI_MAIN,
}


def build_zip(files: dict[str, str | bytes] | None = None, root: str = "myapp-main/") -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for path, content in (files or FILES).items():
            zf.writestr(root + path, content)
    return buffer.getvalue()


VALID_LLM_RESULT = {
    "executive_summary": (
        "The application works as a prototype but exposes privileged credentials in the browser bundle and leaves "
        "two tables without Row Level Security. Data access is spread across UI components."
    ),
    "architecture": {"score": "5/10", "summary": "UI components query the database directly; little separation."},
    "database": {"score": 4, "summary": "Missing RLS and an unindexed foreign key on orders.product_id."},
    "security": {"score": 2.4, "summary": "A service_role key and a Stripe live key are committed to source."},
    "remediation": {
        "level": "Medium",
        "rationale": "Secrets rotation and RLS are quick; extracting a data layer is a few weeks of work.",
        "top_priorities": ["Rotate keys", "Enable RLS", "Add FK indexes", "Create data layer", "Add tests", "Extra"],
    },
    "findings": [
        {
            "category": "Security",
            "severity": "Critical",
            "title": "Admin page authorises with a service_role key in the browser",
            "description": "The Admin page builds a Supabase client with a service_role key, bypassing RLS for anyone.",
            "recommendation": "Move admin operations to an edge function that checks the caller's role.",
            "file_path": "./src/pages/Admin.tsx:4",
            "effort": "low",
        },
        {
            "category": "database design",
            "severity": "moderate",
            "title": "Orders listing is unbounded",
            "description": "select('*') on orders without pagination will degrade as the table grows.",
            "recommendation": "Paginate with range() and select only needed columns.",
            "file_path": "src/pages/DoesNotExist.tsx",
            "effort": "Low",
        },
        {
            "category": "maintainability",
            "severity": "low",
            "title": "No shared error handling",
            "description": "Supabase errors are ignored throughout the UI, hiding failures from users.",
            "recommendation": "Wrap queries in a hook that surfaces errors via toasts.",
            "file_path": None,
            "effort": "medium",
        },
    ],
}


class FakeLLM:
    """Scripted LLM: returns queued responses in order and records the prompts it received."""

    provider = "fake"
    model = "fake-model"

    def __init__(self, responses: list[str] | None = None) -> None:
        self.responses = responses or ["```json\n" + json.dumps(VALID_LLM_RESULT) + "\n```"]
        self.calls: list[list[dict[str, str]]] = []

    async def chat(self, messages: list[dict[str, str]]) -> LLMResponse:
        self.calls.append(messages)
        content = self.responses[min(len(self.calls) - 1, len(self.responses) - 1)]
        return LLMResponse(content=content, usage=LLMUsage(prompt_tokens=1000, completion_tokens=500))


class FakeGitHub:
    def __init__(self, archive: bytes | None = None) -> None:
        self.archive = archive or build_zip()

    async def fetch_metadata(self, target):  # noqa: ANN001, ANN201
        from app.errors import IngestError
        from app.models.enums import SourceType
        from app.services.github import RepoMetadata

        if target.repo == "missing":
            raise IngestError("GitHub repository not found.", http_status=404)
        return RepoMetadata(
            source_type=SourceType.GITHUB,
            source_key=target.canonical_url,
            name=target.full_name,
            owner=target.owner,
            url=target.canonical_url,
            default_branch="main",
            description="demo",
            primary_language="TypeScript",
            stars=3,
        )

    async def download_archive(self, target, ref):  # noqa: ANN001, ANN201
        return self.archive
