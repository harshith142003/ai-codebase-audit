import io
import zipfile

import pytest

from app.analysis.archive import read_archive
from app.analysis.context import build_context
from app.analysis.scanner import ScanLimits, scan_archive
from app.analysis.secrets import redact
from app.errors import IngestError
from tests.fixtures import ANON_JWT, SERVICE_JWT, STRIPE_LIVE, build_zip

LIMITS = ScanLimits(max_file_bytes=256 * 1024, max_files=4000, max_total_bytes=100 * 1024 * 1024)


@pytest.fixture(scope="module")
def scan():
    return scan_archive(build_zip(), LIMITS)


def test_archive_filters_artifacts_binaries_and_lockfiles(scan):
    paths = {f.path for f in scan.files}
    stats = scan.archive.stats
    assert "package.json" in paths  # top-level "myapp-main/" prefix stripped
    assert not any(p.startswith(("node_modules/", "dist/")) for p in paths)
    assert "public/logo.png" not in paths and "package-lock.json" not in paths
    assert stats.skipped_artifacts == 2 and stats.ignored_dirs == {"node_modules": 1, "dist": 1}
    assert stats.skipped_binary == 1 and stats.skipped_lockfiles == 1


def test_archive_rejects_path_traversal_and_garbage():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("../../etc/passwd", "root:x")
        zf.writestr("ok/main.py", "print(1)")
    contents = read_archive(buf.getvalue(), max_file_bytes=1000, max_files=10, max_total_bytes=10_000)
    assert [f.path for f in contents.files] == ["ok/main.py"]
    assert contents.stats.skipped_unsafe == 1
    with pytest.raises(IngestError):
        read_archive(b"not a zip", max_file_bytes=1000, max_files=10, max_total_bytes=10_000)


def test_stack_and_generator_detection(scan):
    assert scan.generator == "Lovable"
    for fw in ("React", "Vite", "Supabase", "TanStack Query", "Tailwind CSS", "Radix UI / shadcn"):
        assert fw in scan.frameworks


def test_route_extraction(scan):
    routes = {(r.method, r.path, r.kind) for r in scan.routes}
    assert ("GET", "/api/users", "nextjs-app-router") in routes
    assert ("POST", "/api/users", "nextjs-app-router") in routes
    assert ("ANY", "/functions/v1/send-email", "supabase-edge-function") in routes
    assert ("GET", "/health", "python-decorator") in routes
    assert ("POST", "/items", "python-decorator") in routes
    assert {("GET", "/legacy"), ("PUT", "/legacy")} <= {(m, p) for m, p, _ in routes}
    assert not any("_shared" in r.path for r in scan.routes)


def test_sql_schema_analysis(scan):
    db = scan.database
    assert set(db.tables) == {"profiles", "orders", "products"}  # 'fake' inside $$ body ignored
    assert db.tables_without_rls() == ["orders", "products"]
    assert db.policy_counts["profiles"] == 1
    unindexed = {(t, c) for t, c, _ in db.unindexed_foreign_keys()}
    assert unindexed == {("orders", "product_id"), ("products", "vendor_id")}
    assert db.typed_tables == ["profiles", "orders"]
    assert db.data_access == {"orders": ["src/pages/Admin.tsx"]}  # storage bucket excluded


def test_secret_detection_classifies_jwts(scan):
    kinds = {(h.kind, h.file) for h in scan.secret_hits}
    assert ("supabase_service_role_key", "src/pages/Admin.tsx") in kinds
    assert ("supabase_anon_key", "src/integrations/supabase/client.ts") in kinds
    assert ("stripe_live_secret", "src/lib/payments.ts") in kinds
    assert not any(h.file == ".env.example" for h in scan.secret_hits)
    assert not any(h.kind == "generic_secret" for h in scan.secret_hits)  # placeholders ignored


def test_static_findings(scan):
    titles = [f.title for f in scan.static_findings]
    severities = [f.severity.value for f in scan.static_findings]
    assert any("service_role" in t for t in titles)
    assert any("Row Level Security not enabled on 2" in t for t in titles)
    assert any("2 foreign-key column(s)" in t for t in titles)
    assert any("Raw HTML" in t for t in titles)
    assert any("client-side variables only" in t for t in titles)
    assert severities == sorted(severities, key=["critical", "high", "medium", "low", "info"].index)


def test_context_redacts_secrets_and_prioritises(scan):
    ctx = build_context(scan, budget_chars=60_000)
    assert SERVICE_JWT not in ctx.files_text and STRIPE_LIVE not in ctx.files_text and ANON_JWT not in ctx.files_text
    assert "[REDACTED:supabase_service_role_key]" in ctx.files_text
    assert ".env" not in ctx.included
    assert ctx.included[0] == "package.json"
    assert ctx.included.index("supabase/migrations/20240101000000_init.sql") < ctx.included.index(
        "src/components/ui/button.tsx"
    )


def test_context_respects_small_budget(scan):
    ctx = build_context(scan, budget_chars=5_000)
    assert ctx.char_count <= 5_400
    assert ctx.omitted


def test_redact_handles_multiple_spans():
    from app.analysis.secrets import SecretHit
    from app.models.enums import Severity

    text = "a=SECRET1 b=SECRET2"
    hits = [
        SecretHit("f", 1, "k1", "l", Severity.HIGH, "", 2, 9),
        SecretHit("f", 1, "k2", "l", Severity.HIGH, "", 12, 19),
    ]
    assert redact(text, hits) == "a=[REDACTED:k1] b=[REDACTED:k2]"
