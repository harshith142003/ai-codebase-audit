import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.db.memory_repo import InMemoryAuditRepository
from app.main import create_app
from app.services.audit_service import AuditService
from tests.fixtures import SERVICE_JWT, STRIPE_LIVE, FakeGitHub, FakeLLM, build_zip


def make_client(llm=None, api_key=None):
    settings = Settings(db_backend="memory", llm_api_key="x", api_key=api_key, app_env="test")
    repo = InMemoryAuditRepository()
    service = AuditService(repository=repo, llm=llm or FakeLLM(), github=FakeGitHub(), settings=settings)
    return TestClient(create_app(settings=settings, service=service)), repo


@pytest.fixture
def client():
    c, repo = make_client()
    with c:
        yield c, repo


def test_github_audit_sync_end_to_end(client):
    c, repo = client
    r = c.post("/audits?wait=true", json={"repo_url": "https://github.com/Acme/Shop-App"})
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["status"] == "completed"
    assert body["repository"]["name"] == "acme/shop-app"
    assert body["git_ref"] == "main"
    assert body["generator"] == "Lovable"
    assert body["security"]["score"] == 2 and body["remediation_effort"] == "medium"
    sources = {f["source"] for f in body["findings"]}
    assert sources == {"static", "llm"}
    assert body["critical_count"] >= 2 and body["findings_count"] == len(body["findings"])
    # LLM path that does not exist in the repo is dropped (hallucination guard)
    unbounded = next(f for f in body["findings"] if f["title"] == "Orders listing is unbounded")
    assert unbounded["file_path"] is None
    # severities sorted
    order = ["critical", "high", "medium", "low", "info"]
    sev = [f["severity"] for f in body["findings"]]
    assert sev == sorted(sev, key=order.index)

    report = c.get(f"/audits/{body['id']}/report")
    assert report.status_code == 200
    assert report.headers["content-type"].startswith("text/markdown")
    md = report.text
    for section in ("# Codebase Audit: acme/shop-app", "## Executive Summary", "## Scorecard",
                    "## Remediation Estimate: **Medium**", "## Findings Overview", "## Detailed Findings"):
        assert section in md
    assert SERVICE_JWT not in md and STRIPE_LIVE not in md  # full secret values never reach the report


def test_async_flow_returns_202_then_completes(client):
    c, _ = client
    r = c.post("/audits", json={"repo_url": "https://github.com/acme/other", "ref": "develop"})
    assert r.status_code == 202
    accepted = r.json()
    assert accepted["status"] == "queued" and accepted["status_url"].endswith(accepted["audit_id"])
    detail = c.get(f"/audits/{accepted['audit_id']}").json()  # background task ran after the response
    assert detail["status"] == "completed" and detail["git_ref"] == "develop"


def test_zip_upload(client):
    c, _ = client
    r = c.post("/audits/upload?wait=true", files={"file": ("My Project.zip", build_zip(), "application/zip")})
    assert r.status_code == 200, r.text
    assert r.json()["repository"]["name"] == "my-project"
    assert r.json()["repository"]["source_type"] == "zip"
    bad = c.post("/audits/upload", files={"file": ("x.zip", b"definitely not a zip", "application/zip")})
    assert bad.status_code == 422


def test_validation_and_not_found(client):
    c, _ = client
    assert c.post("/audits", json={"repo_url": "https://gitlab.com/a/b"}).status_code == 422
    assert c.post("/audits", json={"repo_url": "https://github.com/a/b", "ref": "../etc"}).status_code == 422
    missing = c.post("/audits", json={"repo_url": "https://github.com/acme/missing"})
    assert missing.status_code == 404 and "not found" in missing.json()["detail"]
    assert c.get("/audits/00000000-0000-0000-0000-000000000000").status_code == 404
    assert c.get("/audits/not-a-uuid").status_code == 422


def test_list_filters(client):
    c, _ = client
    c.post("/audits?wait=true", json={"repo_url": "https://github.com/acme/one"})
    c.post("/audits?wait=true", json={"repo_url": "https://github.com/acme/two"})
    c.post("/audits?wait=true", json={"repo_url": "https://github.com/acme/one"})
    all_ = c.get("/audits").json()
    assert all_["total"] == 3
    one = c.get("/audits", params={"repository": "Acme/One"}).json()
    assert one["total"] == 2 and {i["repository_name"] for i in one["items"]} == {"acme/one"}
    assert c.get("/audits", params={"status": "failed"}).json()["total"] == 0
    assert c.get("/audits", params={"created_after": "2999-01-01T00:00:00"}).json()["total"] == 0
    page = c.get("/audits", params={"limit": 1, "offset": 1}).json()
    assert len(page["items"]) == 1 and page["total"] == 3


def test_llm_failure_marks_run_failed():
    c, _ = make_client(llm=FakeLLM(["garbage"]))
    with c:
        body = c.post("/audits?wait=true", json={"repo_url": "https://github.com/acme/app"}).json()
        assert body["status"] == "failed" and "schema validation" in body["error_message"]
        report = c.get(f"/audits/{body['id']}/report")
        assert report.status_code == 409 and "failed" in report.json()["detail"]


def test_api_key_enforced():
    c, _ = make_client(api_key="s3cret")
    with c:
        assert c.get("/health").status_code == 200  # health stays public
        assert c.get("/audits").status_code == 401
        assert c.get("/audits", headers={"X-API-Key": "wrong"}).status_code == 401
        assert c.get("/audits", headers={"X-API-Key": "s3cret"}).status_code == 200


async def test_stale_runs_recovered():
    from datetime import datetime, timedelta, timezone

    repo = InMemoryAuditRepository()
    r = await repo.upsert_repository({"source_type": "zip", "source_key": "zip:1", "name": "x"})
    run = await repo.create_audit_run({"repository_id": r["id"], "llm_provider": "p", "llm_model": "m"})
    repo.runs[run["id"]]["created_at"] -= timedelta(hours=1)
    assert await repo.fail_stale_runs(datetime.now(timezone.utc) - timedelta(minutes=20), "interrupted") == 1
    assert (await repo.get_audit(run["id"]))["status"] == "failed"
