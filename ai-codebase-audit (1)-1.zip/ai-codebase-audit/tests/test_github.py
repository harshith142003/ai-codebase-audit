import httpx
import pytest

from app.config import Settings
from app.errors import IngestError
from app.services.github import GitHubClient, parse_github_url


def client(handler, token=None) -> GitHubClient:
    settings = Settings(db_backend="memory", llm_api_key="x", github_token=token)
    return GitHubClient(settings, httpx.AsyncClient(transport=httpx.MockTransport(handler)))


def test_parse_github_url_variants():
    t = parse_github_url("https://github.com/Owner/Repo.git")
    assert (t.owner, t.repo, t.ref, t.full_name) == ("Owner", "Repo", None, "owner/repo")
    assert parse_github_url("https://github.com/o/r/tree/feature/x").ref == "feature/x"
    with pytest.raises(IngestError):
        parse_github_url("https://example.com/o/r")


async def test_metadata_degrades_gracefully_when_rate_limited():
    rate_limited = lambda req: httpx.Response(403, headers={"x-ratelimit-remaining": "0"})  # noqa: E731
    meta = await client(rate_limited).fetch_metadata(parse_github_url("https://github.com/acme/app"))
    assert meta.name == "acme/app" and meta.default_branch is None


async def test_metadata_404_is_an_error():
    with pytest.raises(IngestError) as exc:
        await client(lambda req: httpx.Response(404)).fetch_metadata(parse_github_url("https://github.com/a/b"))
    assert exc.value.http_status == 404


async def test_archive_url_depends_on_token_and_size_cap_enforced():
    seen = []

    def handler(req):
        seen.append(str(req.url))
        return httpx.Response(200, content=b"x" * 1024)

    target = parse_github_url("https://github.com/acme/app")
    await client(handler).download_archive(target, "HEAD")
    await client(handler, token="t").download_archive(target, "main")
    assert seen == [
        "https://github.com/acme/app/archive/HEAD.zip",
        "https://api.github.com/repos/acme/app/zipball/main",
    ]

    big = lambda req: httpx.Response(200, content=b"x" * (41 * 1024 * 1024))  # noqa: E731
    with pytest.raises(IngestError) as exc:
        await client(big).download_archive(target, "HEAD")
    assert exc.value.http_status == 413
