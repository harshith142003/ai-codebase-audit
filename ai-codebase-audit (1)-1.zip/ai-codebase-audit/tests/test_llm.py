import json

import httpx
import pytest

from app.errors import LLMError, LLMOutputError
from app.llm.client import OpenAICompatibleClient
from app.llm.structured import extract_json, generate_structured
from app.models.llm import AuditLLMResult
from tests.fixtures import VALID_LLM_RESULT, FakeLLM


def test_schema_coerces_common_model_quirks():
    result = AuditLLMResult.model_validate(VALID_LLM_RESULT)
    assert result.architecture.score == 5  # "5/10"
    assert result.security.score == 2  # 2.4 rounded
    assert result.remediation.level == "medium"  # "Medium"
    assert len(result.remediation.top_priorities) == 5  # capped
    f0, f1, f2 = result.findings
    assert (f0.category, f0.severity, f0.file_path) == ("security", "critical", "src/pages/Admin.tsx")
    assert (f1.category, f1.severity) == ("database", "medium")  # "database design" / "moderate"
    assert f2.category == "architecture"  # "maintainability"


def test_extract_json_handles_fences_think_blocks_and_prose():
    assert extract_json('```json\n{"a": 1}\n```') == {"a": 1}
    assert extract_json('<think>hmm {"x":0}</think>{"a": 2}') == {"a": 2}
    assert extract_json('Sure! Here it is: {"a": 3} Hope that helps.') == {"a": 3}
    with pytest.raises(ValueError):
        extract_json("no json here")


async def test_repair_loop_recovers_from_invalid_output():
    llm = FakeLLM(["not json at all", json.dumps(VALID_LLM_RESULT)])
    result, usage = await generate_structured(llm, AuditLLMResult, system_prompt="s", user_prompt="u")
    assert isinstance(result, AuditLLMResult)
    assert len(llm.calls) == 2 and usage.prompt_tokens == 2000
    assert "did not match the required JSON schema" in llm.calls[1][-1]["content"]


async def test_repair_loop_gives_up():
    llm = FakeLLM(['{"executive_summary": "too short"}'])
    with pytest.raises(LLMOutputError):
        await generate_structured(llm, AuditLLMResult, system_prompt="s", user_prompt="u")
    assert len(llm.calls) == 2


def _client(handler, **kw) -> OpenAICompatibleClient:
    http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
    return OpenAICompatibleClient(
        http=http, provider="groq", base_url="https://llm.test/v1", api_key="k", model="m",
        max_output_tokens=100, reasoning_effort="low", max_retries=3, **kw,
    )


def _ok(content: str = '{"a":1}') -> httpx.Response:
    return httpx.Response(200, json={"choices": [{"message": {"content": content}}],
                                     "usage": {"prompt_tokens": 7, "completion_tokens": 3}})


async def test_client_retries_on_429_with_retry_after(monkeypatch):
    sleeps = []

    async def fake_sleep(s):
        sleeps.append(s)

    monkeypatch.setattr("app.llm.client.asyncio.sleep", fake_sleep)
    responses = iter([httpx.Response(429, headers={"retry-after": "2"}), _ok()])
    resp = await _client(lambda req: next(responses)).chat([{"role": "user", "content": "hi"}])
    assert resp.content == '{"a":1}' and resp.usage.prompt_tokens == 7
    assert sleeps == [2.0]


async def test_client_drops_optional_params_after_400():
    seen = []

    def handler(req: httpx.Request) -> httpx.Response:
        body = json.loads(req.content)
        seen.append(body)
        return httpx.Response(400, text="unknown param") if "response_format" in body else _ok()

    await _client(handler).chat([{"role": "user", "content": "hi"}])
    assert "reasoning_effort" in seen[0] and "response_format" not in seen[1]
    assert seen[1]["model"] == "m" and seen[0]["messages"] == seen[1]["messages"]


async def test_client_raises_on_auth_error():
    with pytest.raises(LLMError, match="check LLM_API_KEY"):
        await _client(lambda req: httpx.Response(401, text="bad key")).chat([{"role": "user", "content": "x"}])
